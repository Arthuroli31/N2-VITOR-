import json
import matplotlib.pyplot as plt
import pandas as pd

# Carregar os resultados do teste de carga
with open("load_test_results.json", "r") as f:
    results = json.load(f)

# Extrair as métricas de duração e falhas por cenário
scenarios_metrics = results["metrics"]["scenarios"]

# Criar um DataFrame para o relatório
data = []
for scenario, metrics in scenarios_metrics.items():
    data.append({
        "Cenário": scenario.capitalize(),
        "Latência Média (ms)": metrics["http_req_duration"]["avg"],
        "Latência P95 (ms)": metrics["http_req_duration"]["p(95)"],
        "Taxa de Erro (%)": metrics["http_req_failed"]["rate"] * 100
    })

df_report = pd.DataFrame(data)

# Gerar gráfico de barras para Latência Média
plt.figure(figsize=(10, 6))
plt.bar(df_report["Cenário"], df_report["Latência Média (ms)"], color='skyblue')
plt.title("Latência Média por Cenário de Carga")
plt.xlabel("Cenário")
plt.ylabel("Latência Média (ms)")
plt.grid(axis='y', linestyle='--')
plt.savefig("grafico_latencia_media.png")
plt.close()

# Gerar gráfico de barras para Taxa de Erro
plt.figure(figsize=(10, 6))
plt.bar(df_report["Cenário"], df_report["Taxa de Erro (%)"], color='salmon')
plt.title("Taxa de Erro por Cenário de Carga")
plt.xlabel("Cenário")
plt.ylabel("Taxa de Erro (%)")
plt.grid(axis='y', linestyle='--')
plt.savefig("grafico_taxa_erro.png")
plt.close()

print("Gráficos gerados com sucesso!")
