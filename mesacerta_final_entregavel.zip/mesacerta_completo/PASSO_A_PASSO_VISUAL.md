# 🚀 PASSO A PASSO VISUAL - Como Iniciar o MESACERTA

## ⚠️ IMPORTANTE: O erro "backend não está rodando" significa que você precisa iniciar o servidor!

---

## 📝 Siga Estes Passos EXATAMENTE

### **PASSO 1: Extrair o ZIP** 📦

1. Clique com botão direito no arquivo `MESACERTA_COMPLETO_FINAL.zip`
2. Selecione **"Extrair aqui"** ou **"Extract here"**
3. Uma pasta chamada `mesacerta_completo` será criada

---

### **PASSO 2: Instalar Node.js (se ainda não tiver)** 📥

**Verificar se já tem Node.js:**
1. Abra o terminal/cmd
2. Digite: `node --version`
3. Se aparecer algo como `v18.x.x` ou `v20.x.x` → **Você já tem!** Pule para o Passo 3
4. Se aparecer "comando não encontrado" → **Precisa instalar**

**Instalar Node.js:**
1. Acesse: https://nodejs.org
2. Baixe a versão **LTS** (recomendada)
3. Instale normalmente (Next, Next, Install)
4. Reinicie o terminal/cmd
5. Teste novamente: `node --version`

---

### **PASSO 3: Abrir Terminal na Pasta Correta** 💻

#### **Windows:**
1. Abra a pasta `mesacerta_completo` no explorador de arquivos
2. Clique na barra de endereço (onde está o caminho)
3. Digite: `cmd` e pressione Enter
4. Um terminal preto abrirá na pasta correta

#### **Mac:**
1. Abra a pasta `mesacerta_completo` no Finder
2. Clique com botão direito na pasta `backend`
3. Selecione "New Terminal at Folder"

#### **Linux:**
1. Abra a pasta `mesacerta_completo` no gerenciador de arquivos
2. Clique com botão direito
3. Selecione "Open in Terminal"

---

### **PASSO 4: Instalar Dependências do Backend** 📦

No terminal que você abriu, digite **EXATAMENTE** estes comandos:

```bash
cd backend
npm install
```

**O que vai acontecer:**
- Vai aparecer muitas linhas de texto
- Vai baixar pacotes da internet
- Pode demorar 1-2 minutos
- No final, vai voltar para o prompt

**Se der erro "npm não é reconhecido":**
- Você não instalou o Node.js corretamente
- Volte ao Passo 2

---

### **PASSO 5: INICIAR O BACKEND** 🚀

**ESTE É O PASSO MAIS IMPORTANTE!**

No mesmo terminal, digite:

```bash
npm start
```

**Você DEVE ver estas mensagens:**

```
🚀 Servidor rodando na porta 3000
📡 API disponível em http://localhost:3000/api
✅ Conectado ao banco de dados SQLite
✅ Tabela users criada/verificada
✅ Tabela restaurants criada/verificada
✅ Tabela reservations criada/verificada
✅ Restaurante "Restaurante Italiano" inserido
✅ Restaurante "Sushi Bar" inserido
✅ Restaurante "Churrasqueira Premium" inserido
✅ Restaurante "Bistro Francês" inserido
```

**✅ SE VOCÊ VIU ESSAS MENSAGENS → O BACKEND ESTÁ RODANDO!**

**⚠️ NÃO FECHE ESTE TERMINAL!** Deixe ele aberto!

---

### **PASSO 6: Verificar se o Backend Está Funcionando** 🔍

Abra o navegador e acesse:

```
http://localhost:3000/api/health
```

**Você deve ver:**
```json
{"status":"OK","message":"API MESACERTA funcionando","timestamp":"..."}
```

**✅ Se viu isso → Backend está 100% funcionando!**

**❌ Se não carregou → O backend não está rodando, volte ao Passo 5**

---

### **PASSO 7: Abrir o Frontend** 🌐

**Agora que o backend está rodando**, abra o frontend:

#### **Opção A - VS Code com Live Server (RECOMENDADO):**

1. Abra o **VS Code**
2. Clique em **File → Open Folder**
3. Selecione a pasta `mesacerta_completo/frontend`
4. Clique com botão direito no arquivo `index.html`
5. Selecione **"Open with Live Server"**
6. O navegador abrirá automaticamente

**Se não tem Live Server:**
1. No VS Code, clique no ícone de extensões (quadrado no lado esquerdo)
2. Pesquise: "Live Server"
3. Instale a extensão "Live Server" by Ritwick Dey
4. Tente novamente

#### **Opção B - Python (se tiver Python instalado):**

1. Abra **OUTRO terminal** (não feche o do backend!)
2. Navegue até a pasta frontend:
   ```bash
   cd mesacerta_completo/frontend
   python -m http.server 8080
   ```
3. Abra o navegador em: http://localhost:8080

#### **Opção C - Node.js:**

1. Abra **OUTRO terminal**
2. Navegue até a pasta frontend:
   ```bash
   cd mesacerta_completo/frontend
   npx http-server -p 8080
   ```
3. Abra o navegador em: http://localhost:8080

---

### **PASSO 8: Usar o Sistema** 🎉

Agora você deve ver o site funcionando **SEM ERROS**!

1. **Criar uma conta:**
   - Clique em "Registrar"
   - Preencha seus dados
   - Clique em "Registrar"

2. **Fazer login:**
   - Use o email e senha que criou
   - Clique em "Entrar"

3. **Fazer uma reserva:**
   - Navegue pelos restaurantes
   - Clique em "Reservar"
   - Escolha data, horário e número de pessoas
   - Clique em "Confirmar Reserva"

4. **Ver suas reservas:**
   - Clique em "Minhas Reservas" no menu

---

## ❌ PROBLEMAS COMUNS E SOLUÇÕES

### Erro: "Erro ao carregar restaurantes. Verifique se o backend está rodando"

**CAUSA:** O backend NÃO está rodando

**SOLUÇÃO:**
1. Verifique se você executou `npm start` no terminal
2. Verifique se o terminal do backend ainda está aberto
3. Verifique se apareceram as mensagens de sucesso (🚀 Servidor rodando...)
4. Teste acessando: http://localhost:3000/api/health

---

### Erro: "npm não é reconhecido como comando"

**CAUSA:** Node.js não está instalado

**SOLUÇÃO:**
1. Instale o Node.js de https://nodejs.org
2. Reinicie o terminal
3. Tente novamente

---

### Erro: "Porta 3000 já está em uso"

**CAUSA:** Outro programa está usando a porta 3000

**SOLUÇÃO 1 - Fechar o processo:**
- **Windows:** 
  ```bash
  netstat -ano | findstr :3000
  taskkill /PID [número] /F
  ```
- **Mac/Linux:**
  ```bash
  lsof -ti:3000 | xargs kill -9
  ```

**SOLUÇÃO 2 - Usar outra porta:**
1. Abra `backend/server.js`
2. Mude a linha 10: `const PORT = process.env.PORT || 3000;`
3. Para: `const PORT = process.env.PORT || 3001;`
4. Abra `frontend/js/api.js`
5. Mude a linha 2: `const API_URL = 'http://localhost:3000/api';`
6. Para: `const API_URL = 'http://localhost:3001/api';`
7. Reinicie o backend

---

### Erro de CORS

**CAUSA:** Você abriu o HTML diretamente (duplo clique)

**SOLUÇÃO:**
- NÃO abra o `index.html` diretamente
- Use Live Server no VS Code
- OU use Python/Node.js para servir o frontend

---

### Frontend abre mas não mostra restaurantes

**CAUSA:** Backend não está rodando OU frontend não está conectando

**CHECKLIST:**
1. [ ] Backend está rodando? (terminal aberto com mensagens de sucesso)
2. [ ] http://localhost:3000/api/health funciona?
3. [ ] Frontend está sendo servido via HTTP? (Live Server ou Python)
4. [ ] Abra o Console do navegador (F12) e veja se há erros

---

## ✅ CHECKLIST FINAL

Antes de usar o sistema, confirme:

- [ ] Node.js está instalado (`node --version` funciona)
- [ ] Dependências instaladas (`npm install` executado)
- [ ] Backend está rodando (terminal aberto com "🚀 Servidor rodando")
- [ ] http://localhost:3000/api/health retorna `{"status":"OK"...}`
- [ ] Frontend está sendo servido via HTTP (Live Server ou Python)
- [ ] Navegador está aberto em `http://localhost:5500` ou `http://localhost:8080`

**Se TODOS os itens estão marcados → O sistema DEVE funcionar!**

---

## 🎯 RESUMO RÁPIDO

```
1. Extrair ZIP
2. Instalar Node.js (se necessário)
3. Abrir terminal na pasta mesacerta_completo
4. cd backend
5. npm install
6. npm start  ← DEIXAR ABERTO!
7. Abrir frontend com Live Server
8. Usar o sistema!
```

---

## 📞 AINDA COM PROBLEMAS?

Se seguiu TODOS os passos e ainda não funciona:

1. Tire uma foto do terminal do backend
2. Tire uma foto do erro no navegador
3. Abra o Console do navegador (F12) e tire uma foto dos erros
4. Verifique se o firewall não está bloqueando a porta 3000

---

**Última atualização:** Outubro 2025  
**Versão:** 2.0
