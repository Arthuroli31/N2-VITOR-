# 🚀 Guia de Início Rápido - MESACERTA

## Iniciar o Sistema em 3 Passos

### 1️⃣ Instalar Dependências

Abra um terminal na pasta `backend` e execute:

```bash
cd backend
npm install
```

### 2️⃣ Iniciar o Backend

No mesmo terminal, execute:

```bash
npm start
```

Você verá:
```
🚀 Servidor rodando na porta 3000
📡 API disponível em http://localhost:3000/api
✅ Conectado ao banco de dados SQLite
```

**Mantenha este terminal aberto!**

### 3️⃣ Abrir o Frontend

**Opção A - Usando VS Code Live Server (Recomendado):**

1. Abra a pasta `frontend` no VS Code
2. Clique com botão direito em `index.html`
3. Selecione **"Open with Live Server"**

**Opção B - Usando Python:**

Abra outro terminal na pasta `frontend` e execute:

```bash
cd frontend
python -m http.server 8080
```

Depois abra: http://localhost:8080

**Opção C - Usando Node.js:**

```bash
cd frontend
npx http-server -p 8080
```

Depois abra: http://localhost:8080

## 🎯 Testar o Sistema

### Criar uma Conta

1. Clique em **"Registrar"**
2. Preencha:
   - Nome: Seu Nome
   - Email: seu@email.com
   - Telefone: +351 912 345 678
   - Senha: suasenha123
3. Clique em **"Registrar"**

### Fazer uma Reserva

1. Navegue pelos restaurantes
2. Clique em **"Reservar"**
3. Escolha data, horário e número de pessoas
4. Clique em **"Confirmar Reserva"**

### Ver suas Reservas

1. Clique em **"Minhas Reservas"** no menu
2. Veja todas as suas reservas
3. Cancele se necessário

## ⚠️ Problemas Comuns

### "Erro ao carregar restaurantes"

**Solução:** Certifique-se de que o backend está rodando na porta 3000.

### "CORS Error"

**Solução:** Use Live Server ou outro servidor HTTP. Não abra o HTML diretamente do explorador de arquivos.

### Backend não inicia

**Solução:** 
1. Verifique se a porta 3000 está livre
2. Execute `npm install` novamente
3. Verifique se o Node.js está instalado: `node --version`

## 📊 Banco de Dados

O banco de dados SQLite é criado automaticamente em:
```
backend/mesacerta.db
```

### Restaurantes Pré-cadastrados

1. **Restaurante Italiano** - Italiana • €€€
2. **Sushi Bar** - Japonesa • €€€€
3. **Churrasqueira Premium** - Brasileira • €€€
4. **Bistro Francês** - Francesa • €€€€

## 🔧 Comandos Úteis

### Parar o Backend

No terminal onde o backend está rodando, pressione: `Ctrl + C`

### Reiniciar o Backend

```bash
cd backend
npm start
```

### Limpar o Banco de Dados

```bash
cd backend
rm mesacerta.db
npm start
```

O banco será recriado com os dados iniciais.

## 📱 Testar a API Diretamente

### Verificar se a API está funcionando

```bash
curl http://localhost:3000/api/health
```

### Listar restaurantes

```bash
curl http://localhost:3000/api/restaurants
```

### Criar usuário

```bash
curl -X POST http://localhost:3000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Teste","email":"teste@example.com","phone":"123456789","password":"senha123"}'
```

## 🎓 Próximos Passos

Após testar o sistema básico:

1. Leia o `README.md` completo para entender toda a arquitetura
2. Explore os endpoints da API
3. Customize o frontend (cores, imagens, textos)
4. Adicione novos restaurantes via API
5. Implemente novas funcionalidades

## 💡 Dicas

- **Desenvolvimento:** Use `nodemon` para reiniciar automaticamente o backend:
  ```bash
  npm install -g nodemon
  nodemon server.js
  ```

- **Depuração:** Abra o Console do navegador (F12) para ver logs e erros

- **Testes:** Use ferramentas como Postman ou Insomnia para testar a API

---

**Precisa de ajuda?** Consulte o README.md completo ou verifique os logs do backend no terminal.
