const sqlite3 = require('sqlite3').verbose();
const path = require('path');

// Criar conexão com o banco de dados SQLite
const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'mesacerta.db');

// Criar conexão com o banco de dados SQLite
const db = new sqlite3.Database(DB_PATH, (err) => {
    if (err) {
        console.error('Erro ao conectar ao banco de dados:', err.message);
    } else {
        console.log('✅ Conectado ao banco de dados SQLite');
        initializeDatabase();
    }
});

// Inicializar tabelas do banco de dados
function initializeDatabase() {
    // Tabela de usuários
    db.run(`
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            phone TEXT,
            password TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    `, (err) => {
        if (err) {
            console.error('Erro ao criar tabela users:', err.message);
        } else {
            console.log('✅ Tabela users criada/verificada');
        }
    });

    // Tabela de restaurantes
    db.run(`
        CREATE TABLE IF NOT EXISTS restaurants (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            cuisine TEXT NOT NULL,
            rating REAL DEFAULT 0,
            price_range TEXT,
            address TEXT NOT NULL,
            phone TEXT,
            email TEXT,
            description TEXT,
            image_url TEXT,
            is_open BOOLEAN DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    `, (err) => {
        if (err) {
            console.error('Erro ao criar tabela restaurants:', err.message);
        } else {
            console.log('✅ Tabela restaurants criada/verificada');
            insertSampleRestaurants();
        }
    });

    // Tabela de reservas
    db.run(`
        CREATE TABLE IF NOT EXISTS reservations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            restaurant_id INTEGER NOT NULL,
            date TEXT NOT NULL,
            time TEXT NOT NULL,
            guests INTEGER NOT NULL,
            status TEXT DEFAULT 'pending',
            special_requests TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (restaurant_id) REFERENCES restaurants(id)
        )
    `, (err) => {
        if (err) {
            console.error('Erro ao criar tabela reservations:', err.message);
        } else {
            console.log('✅ Tabela reservations criada/verificada');
        }
    });
}

// Inserir restaurantes de exemplo
function insertSampleRestaurants() {
    const checkQuery = 'SELECT COUNT(*) as count FROM restaurants';
    
    db.get(checkQuery, [], (err, row) => {
        if (err) {
            console.error('Erro ao verificar restaurantes:', err.message);
            return;
        }

        // Se já existem restaurantes, não inserir novamente
        if (row.count > 0) {
            console.log('✅ Restaurantes já existem no banco de dados');
            return;
        }

        const restaurants = [
            {
                name: 'Restaurante Italiano',
                cuisine: 'Italiana',
                rating: 4.5,
                price_range: '€€€',
                address: 'Rua das Flores, 123',
                phone: '+351 21 123 4567',
                email: 'info@italiano.pt',
                description: 'Autêntica cozinha italiana com ingredientes frescos e receitas tradicionais.',
                image_url: 'img/restaurant1.jpg',
                is_open: 1
            },
            {
                name: 'Sushi Bar',
                cuisine: 'Japonesa',
                rating: 4.8,
                price_range: '€€€€',
                address: 'Av. Principal, 456',
                phone: '+351 21 234 5678',
                email: 'reservas@sushibar.pt',
                description: 'Sushi fresco e sashimi de alta qualidade preparado por chefs experientes.',
                image_url: 'img/restaurant2.jpg',
                is_open: 1
            },
            {
                name: 'Churrasqueira Premium',
                cuisine: 'Brasileira',
                rating: 4.3,
                price_range: '€€€',
                address: 'Praça Central, 789',
                phone: '+351 21 345 6789',
                email: 'contato@churrasco.pt',
                description: 'Churrasco brasileiro autêntico com carnes nobres e buffet variado.',
                image_url: 'img/restaurant3.jpg',
                is_open: 0
            },
            {
                name: 'Bistro Francês',
                cuisine: 'Francesa',
                rating: 4.6,
                price_range: '€€€€',
                address: 'Rua Elegante, 321',
                phone: '+351 21 456 7890',
                email: 'bonjour@bistro.pt',
                description: 'Culinária francesa refinada em ambiente acolhedor e elegante.',
                image_url: 'img/restaurant4.jpg',
                is_open: 1
            }
        ];

        const insertQuery = `
            INSERT INTO restaurants (name, cuisine, rating, price_range, address, phone, email, description, image_url, is_open)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `;

        restaurants.forEach((restaurant) => {
            db.run(insertQuery, [
                restaurant.name,
                restaurant.cuisine,
                restaurant.rating,
                restaurant.price_range,
                restaurant.address,
                restaurant.phone,
                restaurant.email,
                restaurant.description,
                restaurant.image_url,
                restaurant.is_open
            ], (err) => {
                if (err) {
                    console.error('Erro ao inserir restaurante:', err.message);
                } else {
                    console.log(`✅ Restaurante "${restaurant.name}" inserido`);
                }
            });
        });
    });
}

module.exports = db;
