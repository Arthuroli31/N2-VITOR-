const express = require('express');
const winston = require('winston');
const cors = require('cors');
const bodyParser = require('body-parser');
const promBundle = require('express-prom-bundle');
const jwt = require('jsonwebtoken'); // Necessário para decodificar o token
const db = require('./database');

// Configuração do Logger
const logger = winston.createLogger({
    level: 'info',
    format: winston.format.json(),
    defaultMeta: { service: 'core-service' },
    transports: [
        new winston.transports.Console(),
        // Em produção, adicionaríamos um transporte para um sistema de logs centralizado (ex: ELK, Grafana Loki)
    ],
});

const app = express();
const PORT = process.env.PORT || 3002; // Porta diferente para o serviço Core
const JWT_SECRET = 'mesacerta_secret_key_2025'; // Chave para decodificar o token

// Middlewares
app.use(cors());

// Configuração do Prometheus
const metricsMiddleware = promBundle({
    includeMethod: true,
    includePath: true,
    includeStatusCode: true,
    includeUp: true,
    customLabels: { project_name: 'mesacerta' },
    promClient: {
        collectDefaultMetrics: {}
    }
});
app.use(metricsMiddleware);
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Middleware de autenticação (simplificado para decodificar o token e obter o user_id)
function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        logger.debug('Acesso sem token. Rota pública ou token opcional.');
        req.user = null; // Permite acesso a rotas públicas
        return next();
    }

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) {
            logger.warn('Token inválido no Core Service', { error: err.message });
            req.user = null; // Token inválido, mas permite acesso a rotas públicas
        } else {
            logger.debug('Token decodificado com sucesso', { userId: user.id });
            req.user = user;
        }
        next();
    });
}

// ==================== ROTAS DE RESTAURANTES ====================

// Listar todos os restaurantes (PÚBLICA)
app.get('/api/restaurants', (req, res) => {
    const { search, cuisine } = req.query;
    
    let query = 'SELECT * FROM restaurants WHERE 1=1';
    const params = [];

    if (search) {
        query += ' AND (name LIKE ? OR cuisine LIKE ? OR description LIKE ?)';
        const searchTerm = `%${search}%`;
        params.push(searchTerm, searchTerm, searchTerm);
    }

    if (cuisine && cuisine !== 'all') {
        query += ' AND cuisine = ?';
        params.push(cuisine);
    }

    db.all(query, params, (err, restaurants) => {
        if (err) {
            logger.error('Erro ao buscar restaurantes', { error: err.message, query, params });
            return res.status(500).json({ error: 'Erro ao buscar restaurantes' });
        }

        res.json({ restaurants });
    });
});

// Obter detalhes de um restaurante (PÚBLICA)
app.get('/api/restaurants/:id', (req, res) => {
    const { id } = req.params;

    db.get('SELECT * FROM restaurants WHERE id = ?', [id], (err, restaurant) => {
        if (err) {
            logger.error('Erro ao buscar restaurante por ID', { error: err.message, restaurantId: id });
            return res.status(500).json({ error: 'Erro ao buscar restaurante' });
        }

        if (!restaurant) {
            logger.warn('Restaurante não encontrado', { restaurantId: id });
            return res.status(404).json({ error: 'Restaurante não encontrado' });
        }

        res.json({ restaurant });
    });
});

// Rotas de CRUD de Restaurantes (PRIVADAS - ADMIN)
// Por simplicidade, vamos manter a lógica de CRUD aqui, mas em um cenário real,
// a autorização de ADMIN seria verificada.

// Criar restaurante (ADMIN)
app.post('/api/restaurants', (req, res) => {
    // Em um cenário real, verificaria se req.user é admin
    const { name, cuisine, rating, price_range, address, phone, email, description, image_url, is_open } = req.body;

    if (!name || !cuisine || !address) {
        logger.warn('Tentativa de criar restaurante com dados incompletos', { name, cuisine, address });
        return res.status(400).json({ error: 'Nome, culinária e endereço são obrigatórios' });
    }

    db.run(
        `INSERT INTO restaurants (name, cuisine, rating, price_range, address, phone, email, description, image_url, is_open)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [name, cuisine, rating || 0, price_range, address, phone, email, description, image_url, is_open ? 1 : 0],
        function(err) {
            if (err) {
                logger.error('Erro ao criar restaurante', { error: err.message, name });
                return res.status(500).json({ error: 'Erro ao criar restaurante' });
            }

            logger.info('Restaurante criado com sucesso', { restaurantId: this.lastID, name });
            res.status(201).json({
                message: 'Restaurante criado com sucesso',
                restaurant: { id: this.lastID }
            });
        }
    );
});

// Atualizar restaurante (ADMIN)
app.put('/api/restaurants/:id', (req, res) => {
    // Em um cenário real, verificaria se req.user é admin
    const { id } = req.params;
    const { name, cuisine, rating, price_range, address, phone, email, description, image_url, is_open } = req.body;

    db.run(
        `UPDATE restaurants 
         SET name = ?, cuisine = ?, rating = ?, price_range = ?, address = ?, 
             phone = ?, email = ?, description = ?, image_url = ?, is_open = ?
         WHERE id = ?`,
        [name, cuisine, rating, price_range, address, phone, email, description, image_url, is_open ? 1 : 0, id],
        function(err) {
            if (err) {
                logger.error('Erro ao atualizar restaurante', { error: err.message, restaurantId: id });
                return res.status(500).json({ error: 'Erro ao atualizar restaurante' });
            }

            if (this.changes === 0) {
                logger.warn('Tentativa de atualizar restaurante não encontrado', { restaurantId: id });
                return res.status(404).json({ error: 'Restaurante não encontrado' });
            }

            logger.info('Restaurante atualizado com sucesso', { restaurantId: id });
            res.json({ message: 'Restaurante atualizado com sucesso' });
        }
    );
});

// Deletar restaurante (ADMIN)
app.delete('/api/restaurants/:id', (req, res) => {
    // Em um cenário real, verificaria se req.user é admin
    const { id } = req.params;

    db.run('DELETE FROM restaurants WHERE id = ?', [id], function(err) {
        if (err) {
            logger.error('Erro ao deletar restaurante', { error: err.message, restaurantId: id });
            return res.status(500).json({ error: 'Erro ao deletar restaurante' });
        }

        if (this.changes === 0) {
            logger.warn('Tentativa de deletar restaurante não encontrado', { restaurantId: id });
            return res.status(404).json({ error: 'Restaurante não encontrado' });
        }

        logger.info('Restaurante deletado com sucesso', { restaurantId: id });
        res.json({ message: 'Restaurante deletado com sucesso' });
    });
});

// ==================== ROTAS DE RESERVAS ====================

// Criar reserva (PRIVADA)
app.post('/api/reservations', authenticateToken, (req, res) => {
    const { restaurant_id, date, time, guests, special_requests } = req.body;
    const user_id = req.user ? req.user.id : null;

    if (!user_id) {
        logger.warn('Tentativa de criar reserva sem autenticação');
        return res.status(401).json({ error: 'Autenticação necessária para criar reserva' });
    }

    if (!restaurant_id || !date || !time || !guests) {
        logger.warn('Tentativa de criar reserva com dados incompletos', { userId: user_id, restaurant_id, date, time, guests });
        return res.status(400).json({ error: 'Restaurante, data, horário e número de pessoas são obrigatórios' });
    }

    db.run(
        `INSERT INTO reservations (user_id, restaurant_id, date, time, guests, special_requests, status)
         VALUES (?, ?, ?, ?, ?, ?, 'pending')`,
        [user_id, restaurant_id, date, time, guests, special_requests || ''],
        function(err) {
            if (err) {
                logger.error('Erro ao criar reserva', { error: err.message, userId: user_id, restaurant_id });
                return res.status(500).json({ error: 'Erro ao criar reserva' });
            }

            logger.info('Reserva criada com sucesso', { reservationId: this.lastID, userId: user_id, restaurant_id });
            res.status(201).json({
                message: 'Reserva criada com sucesso',
                reservation: { id: this.lastID }
            });
        }
    );
});

// Listar reservas do usuário (PRIVADA)
app.get('/api/reservations', authenticateToken, (req, res) => {
    const user_id = req.user ? req.user.id : null;

    if (!user_id) {
        logger.warn('Tentativa de listar reservas sem autenticação');
        return res.status(401).json({ error: 'Autenticação necessária para listar reservas' });
    }

    const query = `
        SELECT 
            r.id,
            r.date,
            r.time,
            r.guests,
            r.status,
            r.special_requests,
            r.created_at,
            rest.id as restaurant_id,
            rest.name as restaurant_name,
            rest.address as restaurant_address,
            rest.phone as restaurant_phone
        FROM reservations r
        JOIN restaurants rest ON r.restaurant_id = rest.id
        WHERE r.user_id = ?
        ORDER BY r.date DESC, r.time DESC
    `;

    db.all(query, [user_id], (err, reservations) => {
        if (err) {
            logger.error('Erro ao buscar reservas do usuário', { error: err.message, userId: user_id });
            return res.status(500).json({ error: 'Erro ao buscar reservas' });
        }

        res.json({ reservations });
    });
});

// Obter detalhes de uma reserva (PRIVADA)
app.get('/api/reservations/:id', authenticateToken, (req, res) => {
    const { id } = req.params;
    const user_id = req.user ? req.user.id : null;

    if (!user_id) {
        logger.warn('Tentativa de ver detalhes da reserva sem autenticação', { reservationId: id });
        return res.status(401).json({ error: 'Autenticação necessária para ver detalhes da reserva' });
    }

    const query = `
        SELECT 
            r.*,
            rest.name as restaurant_name,
            rest.address as restaurant_address
        FROM reservations r
        JOIN restaurants rest ON r.restaurant_id = rest.id
        WHERE r.id = ? AND r.user_id = ?
    `;

    db.get(query, [id, user_id], (err, reservation) => {
        if (err) {
            logger.error('Erro ao buscar detalhes da reserva', { error: err.message, reservationId: id, userId: user_id });
            return res.status(500).json({ error: 'Erro ao buscar reserva' });
        }

        if (!reservation) {
            logger.warn('Reserva não encontrada para o usuário', { reservationId: id, userId: user_id });
            return res.status(404).json({ error: 'Reserva não encontrada' });
        }

        res.json({ reservation });
    });
});

// Atualizar reserva (PRIVADA)
app.put('/api/reservations/:id', authenticateToken, (req, res) => {
    const { id } = req.params;
    const user_id = req.user ? req.user.id : null;

    if (!user_id) {
        logger.warn('Tentativa de atualizar reserva sem autenticação', { reservationId: id });
        return res.status(401).json({ error: 'Autenticação necessária para atualizar reserva' });
    }

    const { date, time, guests, special_requests } = req.body;

    db.run(
        `UPDATE reservations 
         SET date = ?, time = ?, guests = ?, special_requests = ?
         WHERE id = ? AND user_id = ? AND status = 'pending'`,
        [date, time, guests, special_requests || '', id, user_id],
        function(err) {
            if (err) {
                logger.error('Erro ao atualizar reserva', { error: err.message, reservationId: id, userId: user_id });
                return res.status(500).json({ error: 'Erro ao atualizar reserva' });
            }

            if (this.changes === 0) {
                logger.warn('Tentativa de atualizar reserva não encontrada ou não editável', { reservationId: id, userId: user_id });
                return res.status(404).json({ error: 'Reserva não encontrada ou não pode ser editada' });
            }

            logger.info('Reserva atualizada com sucesso', { reservationId: id, userId: user_id });
            res.json({ message: 'Reserva atualizada com sucesso' });
        }
    );
});

// Cancelar reserva (PRIVADA)
app.delete('/api/reservations/:id', authenticateToken, (req, res) => {
    const { id } = req.params;
    const user_id = req.user ? req.user.id : null;

    if (!user_id) {
        logger.warn('Tentativa de cancelar reserva sem autenticação', { reservationId: id });
        return res.status(401).json({ error: 'Autenticação necessária para cancelar reserva' });
    }

    db.run(
        `UPDATE reservations SET status = 'cancelled' WHERE id = ? AND user_id = ?`,
        [id, user_id],
        function(err) {
            if (err) {
                logger.error('Erro ao cancelar reserva', { error: err.message, reservationId: id, userId: user_id });
                return res.status(500).json({ error: 'Erro ao cancelar reserva' });
            }

            if (this.changes === 0) {
                logger.warn('Tentativa de cancelar reserva não encontrada', { reservationId: id, userId: user_id });
                return res.status(404).json({ error: 'Reserva não encontrada' });
            }

            logger.info('Reserva cancelada com sucesso', { reservationId: id, userId: user_id });
            res.json({ message: 'Reserva cancelada com sucesso' });
        }
    );
});

// ==================== ROTA DE TESTE ====================

app.get('/api/health', (req, res) => {
    logger.info('Health check OK');
    res.json({ 
        status: 'OK', 
        message: 'Microserviço Core funcionando',
        timestamp: new Date().toISOString()
    });
});

// O endpoint /metrics é adicionado automaticamente pelo promBundle

// Iniciar servidor
if (require.main === module) {
    app.listen(PORT, () => {
        logger.info(`🚀 Microserviço Core rodando na porta ${PORT}`);
    });
}

module.exports = app;
