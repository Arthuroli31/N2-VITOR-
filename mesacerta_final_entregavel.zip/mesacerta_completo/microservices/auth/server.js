const express = require('express');
const winston = require('winston');
const cors = require('cors');
const bodyParser = require('body-parser');
const promBundle = require('express-prom-bundle');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('./database');

// Configuração do Logger
const logger = winston.createLogger({
    level: 'info',
    format: winston.format.json(),
    defaultMeta: { service: 'auth-service' },
    transports: [
        new winston.transports.Console(),
        // Em produção, adicionaríamos um transporte para um sistema de logs centralizado (ex: ELK, Grafana Loki)
    ],
});

const app = express();
const PORT = process.env.PORT || 3001; // Porta diferente para o serviço de autenticação
const JWT_SECRET = 'mesacerta_secret_key_2025'; // Em produção, usar variável de ambiente

// Middlewares
app.use(cors());

// Configuração do Prometheus
const metricsMiddleware = promBundle({
    includeMethod: true,
    includePath: true,
    includeStatusCode: true,
    includeUp: true,
    customLabels: { project_name: 'mesacerta' },
    promClient: {
        collectDefaultMetrics: {}
    }
});
app.use(metricsMiddleware);
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Middleware de autenticação (apenas para /me)
function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        logger.warn('Tentativa de acesso sem token');
        return res.status(401).json({ error: 'Token não fornecido' });
    }

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) {
            logger.error('Token inválido', { error: err.message });
            return res.status(403).json({ error: 'Token inválido' });
        }
        req.user = user;
        next();
    });
}

// ==================== ROTAS DE AUTENTICAÇÃO ====================

// Registro de usuário
app.post('/api/auth/register', async (req, res) => {
    const { name, email, phone, password } = req.body;

    if (!name || !email || !password) {
        logger.warn('Tentativa de registro com dados incompletos', { email });
        return res.status(400).json({ error: 'Nome, email e senha são obrigatórios' });
    }

    db.get('SELECT * FROM users WHERE email = ?', [email], async (err, user) => {
        if (err) {
            logger.error('Erro ao verificar email no registro', { error: err.message, email });
            return res.status(500).json({ error: 'Erro ao verificar email' });
        }

        if (user) {
            logger.warn('Tentativa de registro com email já cadastrado', { email });
            return res.status(400).json({ error: 'Email já cadastrado' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        db.run(
            'INSERT INTO users (name, email, phone, password) VALUES (?, ?, ?, ?)',
            [name, email, phone, hashedPassword],
            function(err) {
                if (err) {
                    logger.error('Erro ao criar usuário', { error: err.message, email });
                    return res.status(500).json({ error: 'Erro ao criar usuário' });
                }

                logger.info('Usuário registrado com sucesso', { userId: this.lastID, email });
                res.status(201).json({
                    message: 'Usuário criado com sucesso',
                    user: {
                        id: this.lastID,
                        name,
                        email
                    }
                });
            }
        );
    });
});

// Login de usuário
app.post('/api/auth/login', (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        logger.warn('Tentativa de login com dados incompletos', { email });
        return res.status(400).json({ error: 'Email e senha são obrigatórios' });
    }

    db.get('SELECT * FROM users WHERE email = ?', [email], async (err, user) => {
        if (err) {
            logger.error('Erro ao buscar usuário no login', { error: err.message, email });
            return res.status(500).json({ error: 'Erro ao buscar usuário' });
        }

        if (!user) {
            logger.warn('Tentativa de login com email não encontrado', { email });
            return res.status(401).json({ error: 'Email ou senha incorretos' });
        }

        const validPassword = await bcrypt.compare(password, user.password);
        if (!validPassword) {
            logger.warn('Tentativa de login com senha incorreta', { email });
            return res.status(401).json({ error: 'Email ou senha incorretos' });
        }

        const token = jwt.sign(
            { id: user.id, email: user.email },
            JWT_SECRET,
            { expiresIn: '24h' }
        );

        logger.info('Login realizado com sucesso', { userId: user.id, email: user.email });
        res.json({
            message: 'Login realizado com sucesso',
            token,
            user: {
                id: user.id,
                name: user.name,
                email: user.email
            }
        });
    });
});

// Obter dados do usuário logado
app.get('/api/auth/me', authenticateToken, (req, res) => {
    db.get('SELECT id, name, email, phone FROM users WHERE id = ?', [req.user.id], (err, user) => {
        if (err) {
            logger.error('Erro ao buscar dados do usuário logado', { error: err.message, userId: req.user.id });
            return res.status(500).json({ error: 'Erro ao buscar usuário' });
        }

        if (!user) {
            logger.warn('Usuário logado não encontrado no banco de dados', { userId: req.user.id });
            return res.status(404).json({ error: 'Usuário não encontrado' });
        }

        res.json({ user });
    });
});

// ==================== ROTA DE TESTE ====================

app.get('/api/health', (req, res) => {
    logger.info('Health check OK');
    res.json({ 
        status: 'OK', 
        message: 'Microserviço de Autenticação funcionando',
        timestamp: new Date().toISOString()
    });
});

// O endpoint /metrics é adicionado automaticamente pelo promBundle

// Iniciar servidor
if (require.main === module) {
    app.listen(PORT, () => {
        logger.info(`🚀 Servidor de Autenticação rodando na porta ${PORT}`);
    });
}

module.exports = app;
