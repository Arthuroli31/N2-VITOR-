# 🔍 VERIFICAR SE O SISTEMA ESTÁ FUNCIONANDO

## Use este guia para diagnosticar problemas

---

## ✅ TESTE 1: Node.js Instalado?

Abra o terminal e execute:

```bash
node --version
```

**Resultado esperado:**
```
v18.x.x
```
ou
```
v20.x.x
```

**❌ Se aparecer "comando não encontrado":**
- Node.js NÃO está instalado
- Instale de: https://nodejs.org
- Reinicie o terminal
- Teste novamente

---

## ✅ TESTE 2: Dependências Instaladas?

No terminal, na pasta `backend`, execute:

```bash
cd backend
ls node_modules
```

**Resultado esperado:**
- Deve listar várias pastas (express, cors, bcryptjs, etc)

**❌ Se aparecer "pasta não encontrada":**
- Dependências NÃO foram instaladas
- Execute: `npm install`
- Aguarde terminar
- Teste novamente

---

## ✅ TESTE 3: Backend Está Rodando?

No terminal, execute:

```bash
cd backend
npm start
```

**Resultado esperado:**
```
🚀 Servidor rodando na porta 3000
📡 API disponível em http://localhost:3000/api
✅ Conectado ao banco de dados SQLite
✅ Tabela users criada/verificada
✅ Tabela restaurants criada/verificada
✅ Tabela reservations criada/verificada
```

**❌ Se aparecer erro:**
- Veja qual é o erro específico
- Erros comuns:
  - "Porta já em uso" → Feche outros programas ou use outra porta
  - "Módulo não encontrado" → Execute `npm install` novamente
  - "Permissão negada" → Execute como administrador

---

## ✅ TESTE 4: API Está Respondendo?

**Com o backend rodando**, abra o navegador e acesse:

```
http://localhost:3000/api/health
```

**Resultado esperado:**
```json
{
  "status": "OK",
  "message": "API MESACERTA funcionando",
  "timestamp": "2025-10-08T..."
}
```

**❌ Se não carregar:**
- Backend NÃO está rodando
- Volte ao TESTE 3
- Certifique-se de que o terminal está aberto

---

## ✅ TESTE 5: Listar Restaurantes?

No navegador, acesse:

```
http://localhost:3000/api/restaurants
```

**Resultado esperado:**
- Deve mostrar um JSON com 4 restaurantes
- Cada restaurante tem: id, name, cuisine, rating, etc

**❌ Se não carregar:**
- Backend não está funcionando corretamente
- Verifique os logs no terminal do backend

---

## ✅ TESTE 6: Frontend Está Servido via HTTP?

**Abra o frontend com Live Server ou Python**

No navegador, verifique a URL:

**✅ URLs corretas:**
- `http://localhost:5500/index.html` (Live Server)
- `http://localhost:8080/index.html` (Python)
- `http://127.0.0.1:5500/index.html` (Live Server)

**❌ URLs ERRADAS:**
- `file:///C:/Users/.../index.html` ← NÃO FUNCIONA!
- `file:///home/.../index.html` ← NÃO FUNCIONA!

**Se a URL começa com `file://`:**
- Você abriu o HTML diretamente (duplo clique)
- Isso NÃO funciona por causa do CORS
- Use Live Server ou Python

---

## ✅ TESTE 7: Console do Navegador

Abra o Console do navegador (F12) e verifique:

**✅ Sem erros:**
- Deve ver: "page loaded"
- Deve ver: "do check cookie accept prompt"
- NÃO deve ter erros vermelhos

**❌ Se tiver erros:**
- `CORS error` → Frontend não está sendo servido via HTTP
- `Failed to fetch` → Backend não está rodando
- `net::ERR_CONNECTION_REFUSED` → Backend não está rodando

---

## ✅ TESTE 8: Criar Usuário via API (Teste Direto)

No terminal, execute:

```bash
curl -X POST http://localhost:3000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Teste","email":"teste@example.com","phone":"123456789","password":"senha123"}'
```

**Resultado esperado:**
```json
{
  "message": "Usuário criado com sucesso",
  "user": {
    "id": 1,
    "name": "Teste",
    "email": "teste@example.com"
  }
}
```

**❌ Se der erro:**
- Backend não está funcionando
- Verifique o terminal do backend para ver o erro

---

## ✅ TESTE 9: Fazer Login via API (Teste Direto)

No terminal, execute:

```bash
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"teste@example.com","password":"senha123"}'
```

**Resultado esperado:**
```json
{
  "message": "Login realizado com sucesso",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": 1,
    "name": "Teste",
    "email": "teste@example.com"
  }
}
```

**❌ Se der erro:**
- "Email ou senha incorretos" → Usuário não foi criado no TESTE 8
- Outro erro → Backend não está funcionando

---

## 📊 RESUMO DOS TESTES

| Teste | O que verifica | Status |
|-------|----------------|--------|
| 1 | Node.js instalado | ⬜ |
| 2 | Dependências instaladas | ⬜ |
| 3 | Backend rodando | ⬜ |
| 4 | API respondendo | ⬜ |
| 5 | Restaurantes carregando | ⬜ |
| 6 | Frontend via HTTP | ⬜ |
| 7 | Sem erros no console | ⬜ |
| 8 | Criar usuário funciona | ⬜ |
| 9 | Login funciona | ⬜ |

**Se TODOS os testes passarem → O sistema DEVE funcionar!**

---

## 🔧 DIAGNÓSTICO RÁPIDO

### Sintoma: "Erro ao carregar restaurantes"

**Possíveis causas:**
1. Backend não está rodando → TESTE 3
2. API não está respondendo → TESTE 4
3. Frontend via `file://` → TESTE 6

### Sintoma: "npm não é reconhecido"

**Causa:** Node.js não instalado → TESTE 1

### Sintoma: "Porta 3000 já em uso"

**Causa:** Outro programa usando a porta

**Solução:**
```bash
# Windows
netstat -ano | findstr :3000
taskkill /PID [número] /F

# Mac/Linux
lsof -ti:3000 | xargs kill -9
```

### Sintoma: "CORS error"

**Causa:** Frontend não está via HTTP → TESTE 6

**Solução:** Use Live Server ou Python

---

## 📸 COMO REPORTAR PROBLEMAS

Se todos os testes falharem, forneça:

1. **Screenshot do terminal do backend** após `npm start`
2. **Screenshot do navegador** mostrando o erro
3. **Screenshot do Console (F12)** mostrando erros em vermelho
4. **Resultado dos TESTES 1-5**
5. **Sistema operacional** (Windows 10/11, Mac, Linux)
6. **Versão do Node.js** (resultado de `node --version`)

---

**Última atualização:** Outubro 2025
