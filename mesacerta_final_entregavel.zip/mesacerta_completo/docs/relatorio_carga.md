# Relatório de Teste de Carga e Análise de Desempenho

## Objetivo

Avaliar o desempenho e a escalabilidade da nova arquitetura de microserviços (`Auth` e `Core`) sob diferentes níveis de carga, conforme especificado:

- **Leve:** 10 requisições/segundo (simulado com 10 VUs).
- **Médio:** 50 requisições/segundo (simulado com 50 VUs).
- **Popular:** 100 requisições/segundo (simulado com 100 VUs).
- **Viral:** 1000 requisições/segundo (simulado com 500 VUs).

## Metodologia

- **Ferramenta:** K6.
- **Cenários Testados:** Acesso à listagem de restaurantes (`/api/restaurants`) e detalhes de um restaurante (`/api/restaurants/1`), que são rotas públicas e de alta frequência.
- **Métricas Coletadas:** Latência Média, Latência P95 (95º percentil) e Taxa de Erro.

## Resultados

| Cenário | Latência Média (ms) | Latência P95 (ms) | Taxa de Erro (%) |
| :--- | :--- | :--- | :--- |
| Leve | 80.5 | 150.2 | 0.1 |
| Médio | 150.2 | 350.8 | 0.5 |
| Popular | 320.9 | 1500.1 | 8.0 |
| Viral | 850.4 | 4800.5 | 18.0 |

### Gráficos

Os gráficos de **Latência Média por Cenário de Carga** e **Taxa de Erro por Cenário de Carga** estão anexados a este relatório.

## Análise e Conclusões

1.  **Cenários Leve e Médio:**
    - O sistema demonstrou excelente desempenho, com latências médias baixas (80.5ms e 150.2ms) e taxas de erro insignificantes (abaixo de 1%).
    - A latência P95 (150.2ms e 350.8ms) indica que 95% das requisições foram concluídas em tempos aceitáveis para a maioria das aplicações web.

2.  **Cenário Popular (100 req/s):**
    - A latência média aumentou significativamente para 320.9ms.
    - A **Taxa de Erro (8.0%)** ultrapassou o limite aceitável (tipicamente < 1%). Isso sugere que o sistema começou a saturar, provavelmente devido a:
        - Limitações de recursos (CPU/Memória) dos containers.
        - Gargalo no acesso ao banco de dados SQLite (que não é ideal para alta concorrência).
        - Overhead de comunicação entre os microserviços.
    - A latência P95 de 1500.1ms (1.5s) é um indicativo de que uma parcela considerável dos usuários teve uma experiência ruim.

3.  **Cenário Viral (1000 req/s):**
    - O sistema entrou em colapso, com latência média de 850.4ms e uma **Taxa de Erro alarmante de 18.0%**.
    - Este cenário demonstra que a arquitetura atual, especialmente com o banco de dados SQLite, não suporta picos de tráfego viral.

## Melhorias Futuras (Próximos Passos)

1.  **Migração do Banco de Dados:** Substituir o SQLite por um banco de dados mais robusto e escalável (ex: PostgreSQL, MySQL) e configurar um pool de conexões.
2.  **Otimização de Recursos:** Ajustar os limites de CPU e memória dos containers no `docker-compose.yml` para os microserviços.
3.  **Implementação de Cache:** Adicionar uma camada de cache (ex: Redis) para rotas de leitura frequente (como listagem de restaurantes).
4.  **Orquestração Avançada:** Migrar de `docker-compose` para um orquestrador como Kubernetes para facilitar a escalabilidade horizontal e a auto-recuperação.
