# Parte 4 - Observabilidade

## Logs Estruturados (Winston)

Implementamos logs estruturados (JSON) em ambos os microserviços (`auth` e `core`) utilizando a biblioteca **Winston**.

- **Nível de Log:** `info`, `warn`, `error`, `debug`.
- **Formato:** JSON, facilitando a ingestão por sistemas de log centralizados.
- **Contexto:** Cada log inclui o campo `service` (`auth-service` ou `core-service`) para fácil filtragem.

**Exemplo de Log (Auth Service):**
```json
{"level":"info","message":"Login realizado com sucesso","userId":1,"email":"user@example.com","service":"auth-service","timestamp":"2025-12-01T18:00:00.000Z"}
```

## Métricas (Prometheus)

Utilizamos o middleware `express-prom-bundle` para expor métricas no formato Prometheus em ambos os microserviços.

- **Endpoint:** `/metrics`
- **Métricas Coletadas:**
    - `http_request_duration_seconds`: Latência das requisições HTTP.
    - `http_requests_total`: Contador de requisições HTTP.
    - Métricas padrão do Node.js (uso de CPU, memória, etc.).

## Monitoramento (Prometheus e Grafana)

Configuramos um stack de monitoramento composto por:

1.  **Prometheus:** Coleta as métricas dos microserviços (`auth:3001/metrics` e `core:3002/metrics`) e armazena a série temporal.
2.  **Grafana:** Interface de visualização para criar dashboards a partir dos dados do Prometheus.

**Configuração no `docker-compose.yml`:**
- **Prometheus:** Porta `9090` (mapeada para o host).
- **Grafana:** Porta `3004` (mapeada para o host).

## Health Check (`/health`)

Ambos os microserviços (`auth` e `core`) expõem um endpoint `/api/health` para verificação de status. O frontend (Nginx) também possui um health check simples em `/health`.

- **Auth Service:** `http://auth:3001/api/health`
- **Core Service:** `http://core:3002/api/health`
- **Frontend (Nginx):** `http://frontend/health`

## Alertas Simples

Para demonstrar a capacidade de alerta, o Prometheus está configurado para monitorar a disponibilidade dos serviços. Em um cenário real, configuraríamos regras de alerta no Prometheus e as integraríamos a um Alertmanager.

---

**Próxima Etapa:** Execução de Testes de Carga e Análise de Desempenho.
