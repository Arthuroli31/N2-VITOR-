# MESACERTA - Sistema Completo de Reservas de Restaurantes

Sistema completo de reservas de restaurantes com **frontend**, **backend** e **banco de dados** integrados.

## 📋 Índice

- [Visão Geral](#visão-geral)
- [Tecnologias Utilizadas](#tecnologias-utilizadas)
- [Estrutura do Projeto](#estrutura-do-projeto)
- [Instalação e Configuração](#instalação-e-configuração)
- [Como Usar](#como-usar)
- [API Endpoints](#api-endpoints)
- [Funcionalidades](#funcionalidades)

## 🎯 Visão Geral

O MESACERTA é uma aplicação web completa que permite aos utilizadores:

- Navegar por restaurantes disponíveis
- Fazer login e criar conta
- Realizar reservas em restaurantes
- Gerir as suas reservas
- Filtrar restaurantes por culinária e pesquisa

## 🛠 Tecnologias Utilizadas

### CI/CD
- GitHub Actions (Workflows configurados)
- Mocha/Chai/Supertest (Testes unitários)

## Status do CI/CD

| Serviço | CI Status | Deploy Status |
| :--- | :--- | :--- |
| **Backend** | [![CI Backend Status](https://img.shields.io/badge/CI%20Backend-Passing-brightgreen)](https://github.com/seu-usuario/seu-repo/actions/workflows/ci-backend.yml) | [![Deploy Backend Status](https://img.shields.io/badge/Deploy%20Homolog-Success-blue)](https://homolog.mesacerta.com) |
| **Frontend** | [![CI Frontend Status](https://img.shields.io/badge/CI%20Frontend-Passing-brightgreen)](https://github.com/seu-usuario/seu-repo/actions/workflows/ci-frontend.yml) | [![Deploy Frontend Status](https://img.shields.io/badge/Deploy%20Homolog-Success-blue)](https://homolog.mesacerta.com) |

**Nota:** Os links e badges acima são **simulados** e devem ser atualizados com o URL real do seu repositório e ambiente de CI/CD.

## Documentação do Fluxo CI/CD (Parte 2)

### Objetivo
Automatizar todo o ciclo de desenvolvimento, garantindo a qualidade do código e o deploy contínuo.

### Fluxo de Execução
1.  **Push/Pull Request (PR):** Qualquer \`push\` para a branch \`main\` ou abertura/atualização de um \`Pull Request\` para \`main\` dispara o pipeline de CI/CD correspondente (Backend ou Frontend).
2.  **Build + Testes Unitários:** O pipeline executa os seguintes passos:
    *   Configuração do ambiente (Node.js 20).
    *   Instalação das dependências (\`npm install\`).
    *   Execução dos testes unitários (\`npm test\`). **O pipeline falhará se os testes falharem.**
3.  **Geração de Artefatos:**
    *   A imagem Docker do serviço é construída (simulado nesta fase).
4.  **Deploy Automático (main):**
    *   Se o push for para a branch \`main\` e o CI for bem-sucedido, um deploy automático para o ambiente de **Homologação** é simulado.

### Como Rodar Testes Localmente

Para o **Backend** (Node.js):

1.  Navegue até o diretório do backend: \`cd backend\`
2.  Instale as dependências: \`npm install\`
3.  Execute os testes: \`npm test\`

### Logs de Execução
O histórico de execuções e os logs detalhados de cada etapa do pipeline podem ser consultados na aba **Actions** do repositório GitHub.

## Próximos Passos
As próximas fases do projeto (Parte 3 e 4) focarão na refatoração para microserviços, containerização com \`docker-compose\` e implementação de observabilidade.

## 📁 Estrutura do Projeto (Antiga) (Atualizada)

```
mesacerta_completo/
├── .github/
│   └── workflows/
│       ├── ci-backend.yml    # Pipeline CI/CD para o Backend
│       └── ci-frontend.yml   # Pipeline CI/CD para o Frontend
├── backend/
│   ├── server.js           # Servidor Express principal
│   ├── database.js         # Configuração do banco de dados
│   ├── package.json        # Dependências do backend
│   ├── Dockerfile          # Definição do container Docker
│   └── test/               # Testes unitários
│       └── health.test.js
│
├── frontend/
│   ├── index.html          # Página principal
│   ├── css/
│   │   └── style.css       # Estilos da aplicação
│   ├── js/
│   │   ├── api.js          # Cliente da API
│   │   └── app.js          # Lógica da aplicação
│   ├── Dockerfile          # Definição do container Docker
│   └── nginx.conf          # Configuração do Nginx para servir o frontend
│
├── docker-compose.yml      # Orquestração de containers
│
└── README.md               # Este arquivo (Atualizado)
```

## 🚀 Instalação e Configuração

### Frontend
- HTML5, CSS3, JavaScript (ES6+)
- Bootstrap 5.3.0
- Font Awesome 6.4.0

### Backend
- Node.js
- Express.js
- SQLite3 (banco de dados)
- JWT (autenticação)
- bcryptjs (encriptação de senhas)

## 📁 Estrutura do Projeto (Antiga)

```
mesacerta_completo/
├── backend/
│   ├── server.js           # Servidor Express principal
│   ├── database.js         # Configuração do banco de dados
│   ├── package.json        # Dependências do backend
│   └── mesacerta.db        # Banco de dados SQLite (gerado automaticamente)
│
├── frontend/
│   ├── index.html          # Página principal
│   ├── css/
│   │   └── style.css       # Estilos da aplicação
│   ├── js/
│   │   ├── api.js          # Cliente da API
│   │   └── app.js          # Lógica da aplicação
│   └── img/                # Imagens dos restaurantes
│       ├── restaurant1.jpg
│       ├── restaurant2.jpg
│       ├── restaurant3.jpg
│       └── restaurant4.jpg
│
└── README.md               # Este arquivo
```

## 🚀 Instalação e Configuração

### Pré-requisitos

- Node.js (versão 14 ou superior)
- npm (geralmente vem com o Node.js)

### Passo 1: Instalar Dependências do Backend

```bash
cd backend
npm install
```

### Passo 2: Iniciar o Backend

```bash
cd backend
npm start
```

O servidor irá iniciar na porta **3000** e criar automaticamente o banco de dados com dados de exemplo.

Você verá a mensagem:
```
🚀 Servidor rodando na porta 3000
📡 API disponível em http://localhost:3000/api
✅ Conectado ao banco de dados SQLite
```

### Passo 3: Abrir o Frontend

Abra o arquivo `frontend/index.html` no seu navegador ou use uma extensão como **Live Server** no VS Code.

**Importante:** O frontend precisa estar rodando em um servidor HTTP (como Live Server) para fazer requisições à API devido às políticas de CORS.

## 💻 Como Usar

### 1. Criar uma Conta

1. Clique em **"Registrar"**
2. Preencha o formulário com:
   - Nome completo
   - Email
   - Telefone
   - Senha (mínimo 6 caracteres)
3. Clique em **"Registrar"**

### 2. Fazer Login

1. Clique em **"Login"**
2. Use suas credenciais ou as credenciais de teste:
   - **Email:** user@example.com
   - **Senha:** password123
3. Clique em **"Entrar"**

### 3. Fazer uma Reserva

1. Navegue pelos restaurantes na página inicial ou em **"Restaurantes"**
2. Clique em **"Reservar"** no restaurante desejado
3. Preencha os dados da reserva:
   - Data
   - Horário
   - Número de pessoas
   - Observações especiais (opcional)
4. Clique em **"Confirmar Reserva"**

### 4. Gerir Reservas

1. Acesse **"Minhas Reservas"** no menu
2. Visualize todas as suas reservas
3. Cancele reservas pendentes se necessário

## 📡 API Endpoints

### Autenticação

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| POST | `/api/auth/register` | Registrar novo usuário |
| POST | `/api/auth/login` | Fazer login |
| GET | `/api/auth/me` | Obter dados do usuário logado |

### Restaurantes

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| GET | `/api/restaurants` | Listar todos os restaurantes |
| GET | `/api/restaurants/:id` | Obter detalhes de um restaurante |
| POST | `/api/restaurants` | Criar restaurante (admin) |
| PUT | `/api/restaurants/:id` | Atualizar restaurante (admin) |
| DELETE | `/api/restaurants/:id` | Deletar restaurante (admin) |

### Reservas

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| POST | `/api/reservations` | Criar nova reserva |
| GET | `/api/reservations` | Listar reservas do usuário |
| GET | `/api/reservations/:id` | Obter detalhes de uma reserva |
| PUT | `/api/reservations/:id` | Atualizar reserva |
| DELETE | `/api/reservations/:id` | Cancelar reserva |

### Exemplos de Requisições

#### Registrar Usuário

```bash
curl -X POST http://localhost:3000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "João Silva",
    "email": "joao@example.com",
    "phone": "+351 912 345 678",
    "password": "senha123"
  }'
```

#### Fazer Login

```bash
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "joao@example.com",
    "password": "senha123"
  }'
```

#### Listar Restaurantes

```bash
curl http://localhost:3000/api/restaurants
```

#### Criar Reserva

```bash
curl -X POST http://localhost:3000/api/reservations \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer SEU_TOKEN_JWT" \
  -d '{
    "restaurant_id": 1,
    "date": "2025-10-15",
    "time": "19:30",
    "guests": 4,
    "special_requests": "Mesa próxima à janela"
  }'
```

## ✨ Funcionalidades

### Implementadas

- ✅ Sistema completo de autenticação (registro e login)
- ✅ Listagem de restaurantes com filtros
- ✅ Pesquisa de restaurantes por nome, culinária ou descrição
- ✅ Sistema de reservas completo
- ✅ Gestão de reservas (visualizar e cancelar)
- ✅ Interface responsiva
- ✅ Validação de formulários
- ✅ Persistência de dados em banco de dados SQLite
- ✅ API REST completa com CRUD
- ✅ Autenticação JWT
- ✅ Senhas encriptadas com bcrypt

### Próximas Melhorias Sugeridas

- [ ] Sistema de avaliações e comentários
- [ ] Upload de imagens de restaurantes
- [ ] Notificações por email
- [ ] Painel administrativo
- [ ] Integração com mapas
- [ ] Sistema de pagamento
- [ ] Histórico de reservas
- [ ] Favoritos

## 🔐 Segurança

- Senhas são encriptadas usando bcrypt
- Autenticação baseada em JWT
- Validação de dados no backend
- Proteção contra SQL injection (usando prepared statements)
- CORS configurado

## 🐛 Troubleshooting

### Backend não inicia

- Verifique se a porta 3000 está disponível
- Certifique-se de que as dependências foram instaladas (`npm install`)

### Frontend não conecta ao backend

- Verifique se o backend está rodando
- Certifique-se de que o frontend está sendo servido via HTTP (use Live Server)
- Verifique o console do navegador para erros

### Erro de CORS

- Certifique-se de que o frontend está rodando em um servidor HTTP
- Verifique se o backend está configurado para aceitar requisições do frontend

## 📝 Licença

MIT License - Sinta-se livre para usar este projeto como base para seus próprios projetos.

## 👥 Autor

**MESACERTA Team**

---

**Versão:** 2.0 (Com Backend Completo)  
**Data:** Outubro 2025
