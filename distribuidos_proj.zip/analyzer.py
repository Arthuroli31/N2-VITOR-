"""
Análise e Visualização de Resultados
"""

import os
import json
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Agg')  # Backend não-interativo
from typing import Dict, List
from config import RESULTS_DIR


class Analyzer:
    """Analisa resultados e gera visualizações"""
    
    def __init__(self, metricas: Dict):
        self.metricas = metricas
        self.results_dir = RESULTS_DIR
        os.makedirs(self.results_dir, exist_ok=True)
    
    def gerar_tabela_status_servidores(self, status_servidores: Dict) -> str:
        """Gera tabela de status dos servidores"""
        tabela = "# Status dos Servidores\n\n"
        tabela += "| Servidor | Atendimentos | Falhas | Redirecionamentos (Enviados/Recebidos) | Atendentes Suporte | Atendentes Vendas |\n"
        tabela += "|----------|--------------|--------|----------------------------------------|-------------------|------------------|\n"
        
        for servidor_id, stats in sorted(status_servidores.items()):
            tabela += f"| {servidor_id} | {stats['atendimentos_realizados']} | {stats['falhas_detectadas']} | "
            tabela += f"{stats['redirecionamentos_enviados']}/{stats['redirecionamentos_recebidos']} | "
            tabela += f"{stats['atendentes_suporte']} | {stats['atendentes_vendas']} |\n"
        
        return tabela
    
    def gerar_tabela_metricas_gerais(self) -> str:
        """Gera tabela de métricas gerais"""
        tabela = "# Métricas Gerais da Simulação\n\n"
        tabela += "| Métrica | Valor |\n"
        tabela += "|---------|-------|\n"
        tabela += f"| Timesteps Executados | {self.metricas['timesteps_executados']:,} |\n"
        tabela += f"| Total de Solicitações | {self.metricas['total_solicitacoes']:,} |\n"
        tabela += f"| Total de Atendimentos | {self.metricas['total_atendimentos']:,} |\n"
        tabela += f"| Total de Falhas | {self.metricas['total_falhas']:,} |\n"
        tabela += f"| Total de Redirecionamentos | {self.metricas['total_redirecionamentos']:,} |\n"
        tabela += f"| Atendentes Adicionados | {self.metricas['atendentes_adicionados']:,} |\n"
        tabela += f"| Atendentes Removidos | {self.metricas['atendentes_removidos']:,} |\n"
        tabela += f"| Buffer Overflow | {'Sim' if self.metricas['buffer_overflow'] else 'Não'} |\n"
        
        if self.metricas['buffer_overflow']:
            tabela += f"| Timestep da Falha | {self.metricas['timestep_falha']:,} |\n"
        
        # Calcular taxa de sucesso
        if self.metricas['total_solicitacoes'] > 0:
            taxa_sucesso = (self.metricas['total_atendimentos'] / self.metricas['total_solicitacoes']) * 100
            tabela += f"| Taxa de Sucesso | {taxa_sucesso:.2f}% |\n"
        
        return tabela
    
    def gerar_grafico_atendimentos_por_servidor(self, status_servidores: Dict):
        """Gera gráfico de barras de atendimentos por servidor"""
        servidores = sorted(status_servidores.keys())
        atendimentos = [status_servidores[s]['atendimentos_realizados'] for s in servidores]
        
        plt.figure(figsize=(10, 6))
        plt.bar(servidores, atendimentos, color=['#3498db', '#2ecc71', '#e74c3c'])
        plt.xlabel('Servidor')
        plt.ylabel('Atendimentos Realizados')
        plt.title('Atendimentos por Servidor')
        plt.grid(axis='y', alpha=0.3)
        
        # Adicionar valores nas barras
        for i, v in enumerate(atendimentos):
            plt.text(i, v, f'{v:,}', ha='center', va='bottom')
        
        filepath = os.path.join(self.results_dir, 'atendimentos_por_servidor.png')
        plt.savefig(filepath, dpi=300, bbox_inches='tight')
        plt.close()
        
        return filepath
    
    def gerar_grafico_falhas_ao_longo_do_tempo(self):
        """Gera gráfico de linha de falhas ao longo do tempo"""
        historico = self.metricas.get('historico_timesteps', [])
        
        if not historico:
            return None
        
        timesteps = [h['timestep'] for h in historico]
        falhas = [h['falhas'] for h in historico]
        
        plt.figure(figsize=(12, 6))
        plt.plot(timesteps, falhas, color='#e74c3c', linewidth=1, alpha=0.7)
        plt.xlabel('Timestep')
        plt.ylabel('Número de Falhas')
        plt.title('Falhas ao Longo do Tempo')
        plt.grid(alpha=0.3)
        
        filepath = os.path.join(self.results_dir, 'falhas_ao_longo_do_tempo.png')
        plt.savefig(filepath, dpi=300, bbox_inches='tight')
        plt.close()
        
        return filepath
    
    def gerar_grafico_distribuicao_redirecionamentos(self, status_servidores: Dict):
        """Gera gráfico de pizza de distribuição de redirecionamentos"""
        servidores = sorted(status_servidores.keys())
        redirecionamentos = [status_servidores[s]['redirecionamentos_recebidos'] for s in servidores]
        
        total = sum(redirecionamentos)
        if total == 0:
            return None
        
        plt.figure(figsize=(8, 8))
        colors = ['#3498db', '#2ecc71', '#e74c3c']
        plt.pie(redirecionamentos, labels=servidores, autopct='%1.1f%%', colors=colors, startangle=90)
        plt.title('Distribuição de Redirecionamentos Recebidos por Servidor')
        
        filepath = os.path.join(self.results_dir, 'distribuicao_redirecionamentos.png')
        plt.savefig(filepath, dpi=300, bbox_inches='tight')
        plt.close()
        
        return filepath
    
    def gerar_grafico_buffers_ao_longo_do_tempo(self):
        """Gera gráfico de linha de buffers ao longo do tempo"""
        historico = self.metricas.get('historico_timesteps', [])
        
        if not historico:
            return None
        
        timesteps = [h['timestep'] for h in historico]
        buffer_suporte = [h['buffer_suporte_total'] for h in historico]
        buffer_vendas = [h['buffer_vendas_total'] for h in historico]
        
        plt.figure(figsize=(12, 6))
        plt.plot(timesteps, buffer_suporte, label='Buffer Suporte', color='#3498db', linewidth=1, alpha=0.7)
        plt.plot(timesteps, buffer_vendas, label='Buffer Vendas', color='#2ecc71', linewidth=1, alpha=0.7)
        plt.xlabel('Timestep')
        plt.ylabel('Tamanho do Buffer')
        plt.title('Tamanho dos Buffers ao Longo do Tempo')
        plt.legend()
        plt.grid(alpha=0.3)
        
        filepath = os.path.join(self.results_dir, 'buffers_ao_longo_do_tempo.png')
        plt.savefig(filepath, dpi=300, bbox_inches='tight')
        plt.close()
        
        return filepath
    
    def gerar_grafico_solicitacoes_vs_atendimentos(self):
        """Gera gráfico comparando solicitações geradas vs atendimentos realizados"""
        historico = self.metricas.get('historico_timesteps', [])
        
        if not historico:
            return None
        
        timesteps = [h['timestep'] for h in historico]
        solicitacoes = [h['solicitacoes'] for h in historico]
        atendimentos = [h['atendimentos'] for h in historico]
        
        plt.figure(figsize=(12, 6))
        plt.plot(timesteps, solicitacoes, label='Solicitações Geradas', color='#e74c3c', linewidth=1, alpha=0.5)
        plt.plot(timesteps, atendimentos, label='Atendimentos Realizados', color='#2ecc71', linewidth=1, alpha=0.7)
        plt.xlabel('Timestep')
        plt.ylabel('Quantidade')
        plt.title('Solicitações Geradas vs Atendimentos Realizados')
        plt.legend()
        plt.grid(alpha=0.3)
        
        filepath = os.path.join(self.results_dir, 'solicitacoes_vs_atendimentos.png')
        plt.savefig(filepath, dpi=300, bbox_inches='tight')
        plt.close()
        
        return filepath
    
    def gerar_relatorio_completo(self, status_servidores: Dict) -> str:
        """Gera relatório completo em Markdown"""
        relatorio = "# Relatório do Sistema de Atendimento Distribuído\n\n"
        relatorio += "## Resumo Executivo\n\n"
        
        if self.metricas['buffer_overflow']:
            relatorio += f"⚠️ **A simulação foi interrompida no timestep {self.metricas['timestep_falha']:,} devido a estouro de buffer.**\n\n"
        else:
            relatorio += f"✅ **A simulação foi concluída com sucesso após {self.metricas['timesteps_executados']:,} timesteps.**\n\n"
        
        relatorio += self.gerar_tabela_metricas_gerais()
        relatorio += "\n\n"
        relatorio += self.gerar_tabela_status_servidores(status_servidores)
        relatorio += "\n\n"
        
        relatorio += "## Visualizações\n\n"
        
        # Gerar gráficos
        graficos = []
        
        g1 = self.gerar_grafico_atendimentos_por_servidor(status_servidores)
        if g1:
            graficos.append(('Atendimentos por Servidor', g1))
        
        g2 = self.gerar_grafico_falhas_ao_longo_do_tempo()
        if g2:
            graficos.append(('Falhas ao Longo do Tempo', g2))
        
        g3 = self.gerar_grafico_distribuicao_redirecionamentos(status_servidores)
        if g3:
            graficos.append(('Distribuição de Redirecionamentos', g3))
        
        g4 = self.gerar_grafico_buffers_ao_longo_do_tempo()
        if g4:
            graficos.append(('Buffers ao Longo do Tempo', g4))
        
        g5 = self.gerar_grafico_solicitacoes_vs_atendimentos()
        if g5:
            graficos.append(('Solicitações vs Atendimentos', g5))
        
        for titulo, filepath in graficos:
            relatorio += f"### {titulo}\n\n"
            relatorio += f"![{titulo}]({os.path.basename(filepath)})\n\n"
        
        relatorio += "## Análise de Resultados\n\n"
        
        # Análise automática
        if self.metricas['total_solicitacoes'] > 0:
            taxa_sucesso = (self.metricas['total_atendimentos'] / self.metricas['total_solicitacoes']) * 100
            relatorio += f"A taxa de sucesso geral do sistema foi de **{taxa_sucesso:.2f}%**, "
            
            if taxa_sucesso >= 95:
                relatorio += "indicando excelente desempenho e resiliência.\n\n"
            elif taxa_sucesso >= 80:
                relatorio += "indicando bom desempenho com margem para otimização.\n\n"
            else:
                relatorio += "indicando necessidade de ajustes na capacidade ou estratégia de redistribuição.\n\n"
        
        if self.metricas['total_redirecionamentos'] > 0 and self.metricas['total_solicitacoes'] > 0:
            taxa_redirecionamento = (self.metricas['total_redirecionamentos'] / self.metricas['total_solicitacoes']) * 100
            relatorio += f"Foram realizados **{self.metricas['total_redirecionamentos']:,} redirecionamentos** "
            relatorio += f"({taxa_redirecionamento:.2f}% das solicitações), demonstrando a capacidade do sistema de "
            relatorio += "redistribuir carga em caso de falhas.\n\n"
        
        if self.metricas['total_falhas'] > 0:
            taxa_falha = (self.metricas['total_falhas'] / self.metricas['total_atendimentos']) * 100 if self.metricas['total_atendimentos'] > 0 else 0
            relatorio += f"O sistema detectou **{self.metricas['total_falhas']:,} falhas** de atendentes "
            relatorio += f"(taxa de falha de {taxa_falha:.2f}%), que foram tratadas através da remoção dos atendentes "
            relatorio += "inativos e adição de novos atendentes.\n\n"
        
        relatorio += "## Conclusões\n\n"
        relatorio += "O sistema demonstrou capacidade de:\n\n"
        relatorio += "1. **Tolerância a Falhas**: Detectar e tratar falhas de atendentes automaticamente\n"
        relatorio += "2. **Redistribuição de Carga**: Redirecionar solicitações entre servidores conforme necessário\n"
        relatorio += "3. **Ajuste Dinâmico**: Adicionar e remover atendentes dinamicamente\n"
        relatorio += "4. **Balanceamento**: Distribuir solicitações de forma inteligente entre servidores\n\n"
        
        if self.metricas['buffer_overflow']:
            relatorio += "⚠️ **Recomendação**: A ocorrência de buffer overflow indica que a capacidade do sistema "
            relatorio += "precisa ser aumentada ou a taxa de geração de solicitações reduzida.\n\n"
        
        return relatorio
    
    def salvar_relatorio(self, relatorio: str, status_servidores: Dict):
        """Salva relatório em arquivo"""
        filepath = os.path.join(self.results_dir, 'relatorio.md')
        with open(filepath, 'w') as f:
            f.write(relatorio)
        
        return filepath
