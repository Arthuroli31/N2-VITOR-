# Arquitetura do Sistema de Atendimento Distribuído

## Visão Geral

Sistema distribuído de atendimento ao cliente com tolerância a falhas, simulando servidores distribuídos (A, B, C) com atendentes especializados em Suporte Técnico e Vendas.

## Componentes Principais

### 1. Servidor (Server)
- **Responsabilidade**: Gerenciar atendentes e processar solicitações
- **Atributos**:
  - ID único (A, B, C)
  - Capacidade máxima de atendimentos simultâneos
  - Lista de atendentes de Suporte Técnico
  - Lista de atendentes de Vendas
  - Buffer de solicitações (capacidade: 50)
  - Status (ativo/inativo)
  
### 2. Atendente (Agent)
- **Responsabilidade**: Processar solicitações de seu tipo
- **Atributos**:
  - ID único
  - Tipo (Suporte Técnico ou Vendas)
  - Servidor associado
  - Status (livre/ocupado)
  - Probabilidade de falha (10%)

### 3. Solicitação (Request)
- **Responsabilidade**: Representar uma requisição de cliente
- **Atributos**:
  - ID único
  - Tipo (Suporte Técnico ou Vendas)
  - Timestamp de criação
  - Servidor atual
  - Histórico de redirecionamentos

### 4. Supervisor
- **Responsabilidade**: Monitorar servidores e redistribuir solicitações
- **Funcionalidades**:
  - Detectar falhas de atendentes
  - Redistribuir solicitações para servidores ativos
  - Adicionar novos atendentes quando necessário
  - Balancear carga entre servidores
  - Gerenciar buffers de solicitações

### 5. Sistema de Logging
- **Responsabilidade**: Registrar eventos e métricas
- **Dados registrados**:
  - Entrada/saída de atendentes
  - Falhas detectadas
  - Redirecionamentos de solicitações
  - Atendimentos concluídos por servidor
  - Status de buffers

## Fluxo de Execução

### Inicialização
1. Criar servidores A, B, C com capacidades definidas
2. Alocar atendentes aleatoriamente (mínimo 100 de cada tipo por servidor)
3. Inicializar supervisor
4. Configurar sistema de logging

### Timestep (iteração)
1. **Geração de solicitações**: Criar 100-20000 solicitações aleatórias
2. **Distribuição**: Supervisor distribui solicitações para servidores com capacidade
3. **Processamento**: Cada atendente livre processa uma solicitação
4. **Simulação de falhas**: 10% de chance de falha por atendente
5. **Detecção de falhas**: Supervisor identifica atendentes que falharam
6. **Recuperação**: 
   - Redistribuir solicitações de atendentes falhados
   - Adicionar novos atendentes se necessário
7. **Verificação de buffer**: Se buffer > 50, marcar como falha e encerrar
8. **Logging**: Registrar métricas do timestep

### Finalização
1. Gerar relatórios consolidados
2. Criar visualizações (gráficos e tabelas)
3. Salvar logs e resultados

## Estratégias de Otimização

### Performance
- Usar estruturas de dados eficientes (deque para filas)
- Logging em batch (a cada 1000 timesteps)
- Agregação de métricas em memória
- Evitar operações I/O desnecessárias

### Tolerância a Falhas
- Redundância de atendentes
- Redistribuição inteligente baseada em capacidade
- Buffer de solicitações por servidor
- Recuperação automática com novos atendentes

### Balanceamento de Carga
- Distribuição baseada em capacidade disponível
- Monitoramento de atendentes livres
- Priorização de servidores com menor carga

## Parâmetros de Configuração

```python
SERVIDORES = {
    'A': {'capacidade': 500},
    'B': {'capacidade': 700},
    'C': {'capacidade': 1000}
}

MIN_ATENDENTES_POR_TIPO = 100
BUFFER_CAPACITY = 50
TIMESTEPS = 1_000_000
SOLICITACOES_MIN = 100
SOLICITACOES_MAX = 20000
PROBABILIDADE_FALHA = 0.10
```

## Estrutura de Arquivos

```
sistema_atendimento/
├── main.py                 # Ponto de entrada
├── models.py              # Classes de domínio
├── supervisor.py          # Lógica do supervisor
├── logger.py              # Sistema de logging
├── analyzer.py            # Análise e visualização
├── config.py              # Configurações
├── logs/                  # Logs gerados
├── results/               # Gráficos e tabelas
└── relatorio.md           # Relatório final
```
