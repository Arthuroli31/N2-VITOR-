"""
Sistema de Atendimento Distribuído com Tolerância a Falhas
Projeto de Sistemas Distribuídos - N2
"""

import random
import time
from typing import List
from models import Servidor
from supervisor import Supervisor
from logger import Logger
from analyzer import Analyzer
from config import (
    SERVIDORES, MIN_ATENDENTES_POR_TIPO, TIMESTEPS, 
    TIPO_SUPORTE, TIPO_VENDAS, LOG_INTERVAL, SAMPLE_INTERVAL
)


def inicializar_servidores() -> List[Servidor]:
    """Inicializa servidores com atendentes aleatórios"""
    servidores = []
    
    for servidor_id, config in SERVIDORES.items():
        servidor = Servidor(servidor_id, config['capacidade'])
        
        # Calcular número de atendentes de cada tipo
        # Garantir mínimo de MIN_ATENDENTES_POR_TIPO de cada tipo
        capacidade_disponivel = config['capacidade'] - (2 * MIN_ATENDENTES_POR_TIPO)
        
        if capacidade_disponivel < 0:
            raise ValueError(f"Capacidade do servidor {servidor_id} insuficiente para atendentes mínimos")
        
        # Distribuir capacidade restante aleatoriamente
        atendentes_suporte_extra = random.randint(0, capacidade_disponivel)
        atendentes_vendas_extra = capacidade_disponivel - atendentes_suporte_extra
        
        num_suporte = MIN_ATENDENTES_POR_TIPO + atendentes_suporte_extra
        num_vendas = MIN_ATENDENTES_POR_TIPO + atendentes_vendas_extra
        
        # Adicionar atendentes de suporte
        for _ in range(num_suporte):
            servidor.adicionar_atendente(TIPO_SUPORTE)
        
        # Adicionar atendentes de vendas
        for _ in range(num_vendas):
            servidor.adicionar_atendente(TIPO_VENDAS)
        
        servidores.append(servidor)
        
        print(f"Servidor {servidor_id} inicializado:")
        print(f"  - Capacidade: {config['capacidade']}")
        print(f"  - Atendentes Suporte: {num_suporte}")
        print(f"  - Atendentes Vendas: {num_vendas}")
        print(f"  - Total: {num_suporte + num_vendas}")
    
    return servidores


def executar_simulacao():
    """Executa a simulação completa"""
    print("=" * 80)
    print("SISTEMA DE ATENDIMENTO DISTRIBUÍDO COM TOLERÂNCIA A FALHAS")
    print("=" * 80)
    print()
    
    # Inicializar componentes
    print("Inicializando sistema...")
    servidores = inicializar_servidores()
    logger = Logger()
    supervisor = Supervisor(servidores, logger)
    
    print(f"\nSimulação configurada para {TIMESTEPS:,} timesteps")
    print("Iniciando simulação...\n")
    
    inicio = time.time()
    ultima_atualizacao = inicio
    
    # Executar timesteps
    for timestep in range(1, TIMESTEPS + 1):
        # Executar timestep
        stats = supervisor.executar_timestep(timestep)
        
        # Verificar buffer overflow
        if stats.get('buffer_overflow', False):
            print(f"\n⚠️  BUFFER OVERFLOW no timestep {timestep:,}!")
            print("Simulação encerrada.")
            break
        
        # Registrar timestep (com amostragem)
        if timestep % SAMPLE_INTERVAL == 0:
            logger.log_timestep(timestep, stats)
        
        # Flush de logs periódico
        if timestep % LOG_INTERVAL == 0:
            logger.flush_eventos()
        
        # Atualizar progresso
        agora = time.time()
        if agora - ultima_atualizacao >= 10:  # Atualizar a cada 10 segundos
            progresso = (timestep / TIMESTEPS) * 100
            tempo_decorrido = agora - inicio
            tempo_estimado = (tempo_decorrido / timestep) * TIMESTEPS
            tempo_restante = tempo_estimado - tempo_decorrido
            
            print(f"Progresso: {progresso:.2f}% ({timestep:,}/{TIMESTEPS:,}) | "
                  f"Tempo decorrido: {tempo_decorrido:.1f}s | "
                  f"Tempo estimado restante: {tempo_restante:.1f}s")
            
            ultima_atualizacao = agora
    
    # Finalizar logging
    print("\nFinalizando logs...")
    logger.finalizar()
    
    tempo_total = time.time() - inicio
    print(f"\nSimulação concluída em {tempo_total:.2f} segundos")
    
    # Gerar análises e relatórios
    print("\nGerando análises e visualizações...")
    metricas = logger.get_metricas()
    status_servidores = supervisor.get_status_servidores()
    
    analyzer = Analyzer(metricas)
    relatorio = analyzer.gerar_relatorio_completo(status_servidores)
    relatorio_path = analyzer.salvar_relatorio(relatorio, status_servidores)
    
    print(f"\n✅ Relatório gerado: {relatorio_path}")
    print(f"✅ Logs salvos em: {logger.log_dir}")
    print(f"✅ Gráficos salvos em: {analyzer.results_dir}")
    
    # Exibir resumo
    print("\n" + "=" * 80)
    print("RESUMO DA SIMULAÇÃO")
    print("=" * 80)
    print(f"Timesteps executados: {metricas['timesteps_executados']:,}")
    print(f"Total de solicitações: {metricas['total_solicitacoes']:,}")
    print(f"Total de atendimentos: {metricas['total_atendimentos']:,}")
    print(f"Total de falhas: {metricas['total_falhas']:,}")
    print(f"Total de redirecionamentos: {metricas['total_redirecionamentos']:,}")
    print(f"Atendentes adicionados: {metricas['atendentes_adicionados']:,}")
    print(f"Atendentes removidos: {metricas['atendentes_removidos']:,}")
    
    if metricas['total_solicitacoes'] > 0:
        taxa_sucesso = (metricas['total_atendimentos'] / metricas['total_solicitacoes']) * 100
        print(f"Taxa de sucesso: {taxa_sucesso:.2f}%")
    
    print("\nStatus dos Servidores:")
    for servidor_id, status in sorted(status_servidores.items()):
        print(f"  Servidor {servidor_id}:")
        print(f"    - Atendimentos: {status['atendimentos_realizados']:,}")
        print(f"    - Falhas: {status['falhas_detectadas']:,}")
        print(f"    - Redirecionamentos (E/R): {status['redirecionamentos_enviados']}/{status['redirecionamentos_recebidos']}")
    
    print("=" * 80)


if __name__ == "__main__":
    # Definir seed para reprodutibilidade (opcional)
    # random.seed(42)
    
    executar_simulacao()
