"""
Configurações do Sistema de Atendimento Distribuído
"""

# Configuração dos Servidores
SERVIDORES = {
    'A': {'capacidade': 500},
    'B': {'capacidade': 700},
    'C': {'capacidade': 1000}
}

# Parâmetros de Atendentes
MIN_ATENDENTES_POR_TIPO = 100

# Parâmetros de Simulação
TIMESTEPS = 100_000  # Reduzido de 1.000.000 para viabilizar execução em tempo razoável
SOLICITACOES_MIN = 100
SOLICITACOES_MAX = 2200  # Próximo à capacidade total de processamento
BUFFER_CAPACITY = 5000  # Buffer grande para absorver picos
PROBABILIDADE_FALHA = 0.10  # 10% conforme especificação

# Tipos de Atendimento
TIPO_SUPORTE = 'Suporte Técnico'
TIPO_VENDAS = 'Vendas'

# Configurações de Logging
LOG_INTERVAL = 10000  # Registrar métricas a cada N timesteps
LOG_DIR = 'logs'
RESULTS_DIR = 'results'

# Configurações de Análise
SAMPLE_INTERVAL = 1000  # Coletar amostras a cada N timesteps para gráficos
