"""
Supervisor do Sistema de Atendimento Distribuído
"""

import random
from typing import List, Dict
from models import Servidor, Solicitacao, Atendente
from logger import Logger
from config import (
    TIPO_SUPORTE, TIPO_VENDAS, SOLICITACOES_MIN, SOLICITACOES_MAX,
    MIN_ATENDENTES_POR_TIPO, SERVIDORES, BUFFER_CAPACITY
)


class Supervisor:
    """Monitora e gerencia o sistema distribuído"""
    
    def __init__(self, servidores: List[Servidor], logger: Logger):
        self.servidores = {s.id: s for s in servidores}
        self.logger = logger
        self.timestep_atual = 0
    
    def gerar_solicitacoes(self) -> List[Solicitacao]:
        """Gera solicitações aleatórias para o timestep"""
        num_solicitacoes = random.randint(SOLICITACOES_MIN, SOLICITACOES_MAX)
        solicitacoes = []
        
        for _ in range(num_solicitacoes):
            tipo = random.choice([TIPO_SUPORTE, TIPO_VENDAS])
            solicitacao = Solicitacao(tipo, self.timestep_atual)
            solicitacoes.append(solicitacao)
        
        return solicitacoes
    
    def distribuir_solicitacoes(self, solicitacoes: List[Solicitacao]) -> bool:
        """
        Distribui solicitações entre servidores
        Retorna False se algum buffer estourou
        """
        for solicitacao in solicitacoes:
            # Encontrar servidor com capacidade disponível
            servidor = self._encontrar_servidor_disponivel(solicitacao.tipo)
            
            if servidor is None:
                # Nenhum servidor disponível, tentar forçar em qualquer um
                servidor = self._servidor_com_menor_buffer(solicitacao.tipo)
            
            servidor.adicionar_solicitacao(solicitacao)
            
            # Verificar se buffer estourou
            buffer = servidor.buffer_suporte if solicitacao.tipo == TIPO_SUPORTE else servidor.buffer_vendas
            if len(buffer) > BUFFER_CAPACITY:
                # Buffer cheio!
                self.logger.log_buffer_overflow(self.timestep_atual, servidor.id)
                return False
        
        return True
    
    def _encontrar_servidor_disponivel(self, tipo_solicitacao: str) -> Servidor:
        """Encontra servidor com atendentes livres e buffer disponível"""
        servidores_disponiveis = []
        
        for servidor in self.servidores.values():
            if not servidor.ativo:
                continue
            
            atendentes_livres = servidor.contar_atendentes_livres(tipo_solicitacao)
            buffer = servidor.buffer_suporte if tipo_solicitacao == TIPO_SUPORTE else servidor.buffer_vendas
            
            if atendentes_livres > 0 and len(buffer) < servidor.capacidade:
                servidores_disponiveis.append((servidor, atendentes_livres))
        
        if not servidores_disponiveis:
            return None
        
        # Retornar servidor com mais atendentes livres
        servidores_disponiveis.sort(key=lambda x: x[1], reverse=True)
        return servidores_disponiveis[0][0]
    
    def _servidor_com_menor_buffer(self, tipo_solicitacao: str) -> Servidor:
        """Retorna servidor com menor buffer para o tipo de solicitação"""
        servidor_escolhido = None
        menor_buffer = float('inf')
        
        for servidor in self.servidores.values():
            if not servidor.ativo:
                continue
            
            buffer = servidor.buffer_suporte if tipo_solicitacao == TIPO_SUPORTE else servidor.buffer_vendas
            if len(buffer) < menor_buffer:
                menor_buffer = len(buffer)
                servidor_escolhido = servidor
        
        return servidor_escolhido
    
    def processar_servidores(self) -> Dict:
        """Processa timestep em todos os servidores"""
        stats_totais = {
            'atendimentos_realizados': 0,
            'falhas': 0,
            'servidores': {}
        }
        
        solicitacoes_falhadas = []
        
        for servidor in self.servidores.values():
            stats = servidor.processar_timestep()
            
            stats_totais['atendimentos_realizados'] += stats['atendimentos']
            stats_totais['falhas'] += stats['falhas']
            stats_totais['servidores'][servidor.id] = {
                'atendimentos': stats['atendimentos'],
                'falhas': stats['falhas'],
                'atendentes_livres_suporte': stats['atendentes_livres_suporte'],
                'atendentes_livres_vendas': stats['atendentes_livres_vendas'],
                'buffer_suporte': stats['buffer_suporte'],
                'buffer_vendas': stats['buffer_vendas']
            }
            
            solicitacoes_falhadas.extend(stats['solicitacoes_falhadas'])
        
        return stats_totais, solicitacoes_falhadas
    
    def tratar_falhas(self, solicitacoes_falhadas: List[Solicitacao]):
        """Trata falhas: remove atendentes inativos, redistribui solicitações, adiciona novos atendentes"""
        atendentes_removidos = []
        
        # Remover atendentes inativos de todos os servidores
        for servidor in self.servidores.values():
            removidos = servidor.remover_atendentes_inativos()
            for atendente in removidos:
                self.logger.log_atendente_removido(
                    self.timestep_atual,
                    servidor.id,
                    atendente.id,
                    atendente.tipo
                )
                atendentes_removidos.append((servidor, atendente))
        
        # Redistribuir solicitações falhadas
        for solicitacao in solicitacoes_falhadas:
            servidor_origem = solicitacao.servidor_atual
            
            # Tentar redistribuir para outro servidor
            servidor_destino = self._encontrar_servidor_para_redistribuir(solicitacao.tipo, servidor_origem)
            
            if servidor_destino:
                servidor_destino.adicionar_solicitacao(solicitacao)
                solicitacao.adicionar_redirecionamento(servidor_origem, servidor_destino.id)
                self.logger.log_redirecionamento(
                    self.timestep_atual,
                    solicitacao.id,
                    servidor_origem,
                    servidor_destino.id,
                    solicitacao.tipo
                )
                
                # Atualizar estatísticas
                if servidor_origem in self.servidores:
                    self.servidores[servidor_origem].redirecionamentos_enviados += 1
                servidor_destino.redirecionamentos_recebidos += 1
        
        # Adicionar novos atendentes para substituir os que falharam
        for servidor, atendente_removido in atendentes_removidos:
            if servidor.capacidade_disponivel() > 0:
                novo_atendente = servidor.adicionar_atendente(atendente_removido.tipo)
                self.logger.log_atendente_adicionado(
                    self.timestep_atual,
                    servidor.id,
                    novo_atendente.id,
                    novo_atendente.tipo
                )
    
    def _encontrar_servidor_para_redistribuir(self, tipo_solicitacao: str, servidor_origem: str) -> Servidor:
        """Encontra servidor para redistribuir uma solicitação"""
        servidores_candidatos = []
        
        for servidor in self.servidores.values():
            if not servidor.ativo or servidor.id == servidor_origem:
                continue
            
            atendentes_livres = servidor.contar_atendentes_livres(tipo_solicitacao)
            buffer = servidor.buffer_suporte if tipo_solicitacao == TIPO_SUPORTE else servidor.buffer_vendas
            
            if atendentes_livres > 0 and len(buffer) < servidor.capacidade:
                servidores_candidatos.append((servidor, atendentes_livres))
        
        if not servidores_candidatos:
            return None
        
        # Retornar servidor com mais atendentes livres
        servidores_candidatos.sort(key=lambda x: x[1], reverse=True)
        return servidores_candidatos[0][0]
    
    def executar_timestep(self, timestep: int) -> Dict:
        """Executa um timestep completo"""
        self.timestep_atual = timestep
        
        # 1. Processar solicitações existentes nos buffers PRIMEIRO
        stats, solicitacoes_falhadas = self.processar_servidores()
        
        # 2. Tratar falhas
        if solicitacoes_falhadas:
            self.tratar_falhas(solicitacoes_falhadas)
        
        # 3. Gerar novas solicitações
        solicitacoes = self.gerar_solicitacoes()
        
        # 4. Distribuir novas solicitações
        if not self.distribuir_solicitacoes(solicitacoes):
            # Buffer overflow!
            return {'buffer_overflow': True}
        
        # 5. Coletar estatísticas
        stats['solicitacoes_geradas'] = len(solicitacoes)
        stats['buffer_suporte_total'] = sum(len(s.buffer_suporte) for s in self.servidores.values())
        stats['buffer_vendas_total'] = sum(len(s.buffer_vendas) for s in self.servidores.values())
        stats['buffer_overflow'] = False
        
        return stats
    
    def get_status_servidores(self) -> Dict:
        """Retorna status atual de todos os servidores"""
        status = {}
        for servidor in self.servidores.values():
            status[servidor.id] = {
                'ativo': servidor.ativo,
                'capacidade': servidor.capacidade,
                'atendentes_suporte': servidor.contar_atendentes_ativos(TIPO_SUPORTE),
                'atendentes_vendas': servidor.contar_atendentes_ativos(TIPO_VENDAS),
                'atendentes_livres_suporte': servidor.contar_atendentes_livres(TIPO_SUPORTE),
                'atendentes_livres_vendas': servidor.contar_atendentes_livres(TIPO_VENDAS),
                'buffer_suporte': len(servidor.buffer_suporte),
                'buffer_vendas': len(servidor.buffer_vendas),
                'atendimentos_realizados': servidor.atendimentos_realizados,
                'falhas_detectadas': servidor.falhas_detectadas,
                'redirecionamentos_recebidos': servidor.redirecionamentos_recebidos,
                'redirecionamentos_enviados': servidor.redirecionamentos_enviados
            }
        return status
