"""
Modelos de domínio do Sistema de Atendimento Distribuído
"""

import random
from collections import deque
from typing import List, Optional
from config import TIPO_SUPORTE, TIPO_VENDAS, BUFFER_CAPACITY, PROBABILIDADE_FALHA


class Solicitacao:
    """Representa uma solicitação de atendimento"""
    _id_counter = 0
    
    def __init__(self, tipo: str, timestamp: int):
        Solicitacao._id_counter += 1
        self.id = Solicitacao._id_counter
        self.tipo = tipo
        self.timestamp = timestamp
        self.servidor_atual = None
        self.historico_redirecionamentos = []
    
    def adicionar_redirecionamento(self, servidor_origem: str, servidor_destino: str):
        """Registra um redirecionamento"""
        self.historico_redirecionamentos.append({
            'origem': servidor_origem,
            'destino': servidor_destino
        })


class Atendente:
    """Representa um atendente especializado"""
    _id_counter = 0
    
    def __init__(self, tipo: str, servidor_id: str):
        Atendente._id_counter += 1
        self.id = f"{tipo[0]}{Atendente._id_counter}"
        self.tipo = tipo
        self.servidor_id = servidor_id
        self.ocupado = False
        self.ativo = True
        self.solicitacao_atual = None
    
    def processar_solicitacao(self, solicitacao: Solicitacao) -> bool:
        """
        Processa uma solicitação
        Retorna True se processou com sucesso, False se falhou
        """
        # Simular falha com probabilidade definida
        if random.random() < PROBABILIDADE_FALHA:
            self.ativo = False
            self.solicitacao_atual = solicitacao
            return False
        
        # Processamento bem-sucedido (simplificado)
        return True
    
    def liberar(self):
        """Libera o atendente"""
        self.ocupado = False
        self.solicitacao_atual = None
    
    def esta_disponivel(self) -> bool:
        """Verifica se o atendente está disponível"""
        return self.ativo and not self.ocupado


class Servidor:
    """Representa um servidor de atendimento"""
    
    def __init__(self, id: str, capacidade: int):
        self.id = id
        self.capacidade = capacidade
        self.atendentes_suporte: List[Atendente] = []
        self.atendentes_vendas: List[Atendente] = []
        self.buffer_suporte = deque()
        self.buffer_vendas = deque()
        self.ativo = True
        
        # Métricas
        self.atendimentos_realizados = 0
        self.falhas_detectadas = 0
        self.redirecionamentos_recebidos = 0
        self.redirecionamentos_enviados = 0
    
    def adicionar_atendente(self, tipo: str):
        """Adiciona um novo atendente ao servidor"""
        atendente = Atendente(tipo, self.id)
        if tipo == TIPO_SUPORTE:
            self.atendentes_suporte.append(atendente)
        else:
            self.atendentes_vendas.append(atendente)
        return atendente
    
    def adicionar_solicitacao(self, solicitacao: Solicitacao):
        """
        Adiciona uma solicitação ao buffer apropriado
        """
        buffer = self.buffer_suporte if solicitacao.tipo == TIPO_SUPORTE else self.buffer_vendas
        buffer.append(solicitacao)
        solicitacao.servidor_atual = self.id
    
    def processar_timestep(self) -> dict:
        """
        Processa um timestep: atendentes livres processam solicitações
        Retorna estatísticas do processamento
        """
        if not self.ativo:
            return {
                'atendimentos': 0,
                'falhas': 0,
                'atendentes_livres_suporte': 0,
                'atendentes_livres_vendas': 0,
                'buffer_suporte': 0,
                'buffer_vendas': 0
            }
        
        atendimentos = 0
        falhas = 0
        solicitacoes_falhadas = []
        
        # Processar solicitações de suporte
        for atendente in self.atendentes_suporte:
            if atendente.esta_disponivel() and len(self.buffer_suporte) > 0:
                solicitacao = self.buffer_suporte.popleft()
                if atendente.processar_solicitacao(solicitacao):
                    atendimentos += 1
                else:
                    falhas += 1
                    solicitacoes_falhadas.append(solicitacao)
        
        # Processar solicitações de vendas
        for atendente in self.atendentes_vendas:
            if atendente.esta_disponivel() and len(self.buffer_vendas) > 0:
                solicitacao = self.buffer_vendas.popleft()
                if atendente.processar_solicitacao(solicitacao):
                    atendimentos += 1
                else:
                    falhas += 1
                    solicitacoes_falhadas.append(solicitacao)
        
        self.atendimentos_realizados += atendimentos
        self.falhas_detectadas += falhas
        
        return {
            'atendimentos': atendimentos,
            'falhas': falhas,
            'solicitacoes_falhadas': solicitacoes_falhadas,
            'atendentes_livres_suporte': self.contar_atendentes_livres(TIPO_SUPORTE),
            'atendentes_livres_vendas': self.contar_atendentes_livres(TIPO_VENDAS),
            'buffer_suporte': len(self.buffer_suporte),
            'buffer_vendas': len(self.buffer_vendas)
        }
    
    def contar_atendentes_livres(self, tipo: str) -> int:
        """Conta quantos atendentes de um tipo estão livres"""
        atendentes = self.atendentes_suporte if tipo == TIPO_SUPORTE else self.atendentes_vendas
        return sum(1 for a in atendentes if a.esta_disponivel())
    
    def contar_atendentes_ativos(self, tipo: str) -> int:
        """Conta quantos atendentes de um tipo estão ativos"""
        atendentes = self.atendentes_suporte if tipo == TIPO_SUPORTE else self.atendentes_vendas
        return sum(1 for a in atendentes if a.ativo)
    
    def remover_atendentes_inativos(self) -> List[Atendente]:
        """Remove atendentes inativos e retorna a lista de removidos"""
        removidos = []
        
        # Remover atendentes de suporte inativos
        ativos_suporte = []
        for atendente in self.atendentes_suporte:
            if atendente.ativo:
                ativos_suporte.append(atendente)
            else:
                removidos.append(atendente)
        self.atendentes_suporte = ativos_suporte
        
        # Remover atendentes de vendas inativos
        ativos_vendas = []
        for atendente in self.atendentes_vendas:
            if atendente.ativo:
                ativos_vendas.append(atendente)
            else:
                removidos.append(atendente)
        self.atendentes_vendas = ativos_vendas
        
        return removidos
    
    def capacidade_disponivel(self) -> int:
        """Retorna a capacidade disponível do servidor"""
        total_atendentes = len(self.atendentes_suporte) + len(self.atendentes_vendas)
        return self.capacidade - total_atendentes
    
    def buffer_cheio(self) -> bool:
        """Verifica se algum buffer está cheio"""
        return len(self.buffer_suporte) > BUFFER_CAPACITY or len(self.buffer_vendas) > BUFFER_CAPACITY
