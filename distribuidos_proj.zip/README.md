# Sistema de Atendimento Distribuído com Tolerância a Falhas

## Descrição

Sistema distribuído de atendimento ao cliente com foco em **tolerância a falhas** e **ajuste dinâmico de capacidade**. O sistema simula servidores distribuídos (A, B, C) com atendentes especializados em Suporte Técnico e Vendas, implementando mecanismos de detecção de falhas, redistribuição de carga e recuperação automática.

## Características Principais

- **Tolerância a Falhas**: Detecção automática de falhas de atendentes e redistribuição de solicitações
- **Ajuste Dinâmico**: Adição e remoção automática de atendentes conforme necessário
- **Balanceamento de Carga**: Distribuição inteligente de solicitações entre servidores
- **Monitoramento**: Sistema de logging completo com métricas detalhadas
- **Visualização**: Geração automática de gráficos e relatórios

## Estrutura do Projeto

```
sistema_atendimento/
├── main.py                 # Ponto de entrada da simulação
├── models.py              # Classes de domínio (Servidor, Atendente, Solicitação)
├── supervisor.py          # Lógica do supervisor (monitoramento e redistribuição)
├── logger.py              # Sistema de logging e métricas
├── analyzer.py            # Análise e visualização de resultados
├── config.py              # Configurações do sistema
├── logs/                  # Logs gerados durante a execução
│   ├── eventos.log        # Log de eventos detalhado
│   └── metricas.json      # Métricas em formato JSON
├── results/               # Resultados e visualizações
│   ├── relatorio.md       # Relatório completo em Markdown
│   └── *.png              # Gráficos gerados
├── README.md              # Este arquivo
└── ARCHITECTURE.md        # Documentação da arquitetura
```

## Requisitos

- Python 3.11+
- matplotlib
- numpy (dependência do matplotlib)

## Instalação

As dependências já estão instaladas no ambiente. Caso precise instalar em outro ambiente:

```bash
pip3 install matplotlib numpy
```

## Configuração

Os parâmetros da simulação podem ser ajustados no arquivo `config.py`:

```python
# Configuração dos Servidores
SERVIDORES = {
    'A': {'capacidade': 500},
    'B': {'capacidade': 700},
    'C': {'capacidade': 1000}
}

# Parâmetros de Simulação
TIMESTEPS = 1_000_000
SOLICITACOES_MIN = 100
SOLICITACOES_MAX = 20000
BUFFER_CAPACITY = 50
PROBABILIDADE_FALHA = 0.10
MIN_ATENDENTES_POR_TIPO = 100
```

## Execução

Para executar a simulação:

```bash
cd sistema_atendimento
python3.11 main.py
```

A simulação executará 1.000.000 de timesteps (ou até ocorrer buffer overflow) e gerará:

1. **Logs de eventos** em `logs/eventos.log`
2. **Métricas em JSON** em `logs/metricas.json`
3. **Relatório completo** em `results/relatorio.md`
4. **Gráficos** em `results/*.png`

## Resultados

Após a execução, os seguintes arquivos serão gerados:

### Logs
- `logs/eventos.log`: Log detalhado de todos os eventos (adição/remoção de atendentes, falhas, redirecionamentos)
- `logs/metricas.json`: Métricas agregadas em formato JSON

### Visualizações
- `results/relatorio.md`: Relatório completo com tabelas, gráficos e análises
- `results/atendimentos_por_servidor.png`: Gráfico de barras comparando atendimentos
- `results/falhas_ao_longo_do_tempo.png`: Gráfico de linha mostrando falhas ao longo do tempo
- `results/distribuicao_redirecionamentos.png`: Gráfico de pizza com distribuição de redirecionamentos
- `results/buffers_ao_longo_do_tempo.png`: Gráfico de linha mostrando evolução dos buffers
- `results/solicitacoes_vs_atendimentos.png`: Gráfico comparando solicitações geradas vs atendimentos

## Arquitetura

### Componentes

1. **Servidor**: Gerencia atendentes e processa solicitações
2. **Atendente**: Processa solicitações de seu tipo (Suporte ou Vendas)
3. **Solicitação**: Representa uma requisição de cliente
4. **Supervisor**: Monitora servidores e redistribui solicitações
5. **Logger**: Registra eventos e métricas
6. **Analyzer**: Gera análises e visualizações

### Fluxo de Execução

Para cada timestep:
1. Gerar solicitações aleatórias (100-20000)
2. Distribuir solicitações entre servidores
3. Processar solicitações (atendentes livres processam uma solicitação cada)
4. Simular falhas (10% de probabilidade por atendente)
5. Detectar e tratar falhas (remover atendentes inativos, redistribuir solicitações, adicionar novos atendentes)
6. Verificar buffers (encerrar se buffer > 50)
7. Registrar métricas

## Tolerância a Falhas

O sistema implementa as seguintes estratégias:

1. **Detecção**: Atendentes que falham são marcados como inativos
2. **Remoção**: Atendentes inativos são removidos do servidor
3. **Redistribuição**: Solicitações de atendentes falhados são redirecionadas para outros servidores
4. **Recuperação**: Novos atendentes são adicionados para substituir os que falharam
5. **Balanceamento**: Redistribuição baseada em capacidade disponível e atendentes livres

## Métricas Coletadas

- Total de solicitações geradas
- Total de atendimentos realizados
- Total de falhas detectadas
- Total de redirecionamentos
- Atendentes adicionados/removidos
- Taxa de sucesso
- Status de buffers
- Atendimentos por servidor
- Redirecionamentos por servidor

## Limitações e Considerações

- **Buffer Capacity**: Se o buffer de qualquer servidor atingir 50 solicitações, a simulação é encerrada
- **Probabilidade de Falha**: 10% de chance de falha por atendente por timestep
- **Capacidade Fixa**: A capacidade dos servidores é fixa (não escala dinamicamente)
- **Processamento Síncrono**: Cada atendente processa uma solicitação por timestep

## Possíveis Melhorias

1. Implementar diferentes estratégias de balanceamento de carga
2. Adicionar priorização de solicitações
3. Implementar recuperação de servidores (não apenas atendentes)
4. Adicionar métricas de latência e tempo de espera
5. Implementar diferentes padrões de falha (falhas em cascata, falhas correlacionadas)
6. Adicionar suporte a múltiplos tipos de atendimento
7. Implementar replicação de estado para recuperação de desastres

## Autores

Projeto desenvolvido para a disciplina de Sistemas Distribuídos - N2

## Licença

Este projeto é de uso acadêmico.
