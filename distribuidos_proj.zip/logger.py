"""
Sistema de Logging do Sistema de Atendimento Distribuído
"""

import os
import json
from datetime import datetime
from typing import List, Dict
from config import LOG_DIR


class Logger:
    """Gerencia logs e métricas do sistema"""
    
    def __init__(self):
        self.log_dir = LOG_DIR
        os.makedirs(self.log_dir, exist_ok=True)
        
        # Arquivos de log
        self.eventos_file = os.path.join(self.log_dir, 'eventos.log')
        self.metricas_file = os.path.join(self.log_dir, 'metricas.json')
        
        # Buffer de eventos para escrita em batch
        self.eventos_buffer = []
        
        # Métricas agregadas
        self.metricas = {
            'total_solicitacoes': 0,
            'total_atendimentos': 0,
            'total_falhas': 0,
            'total_redirecionamentos': 0,
            'atendentes_adicionados': 0,
            'atendentes_removidos': 0,
            'timesteps_executados': 0,
            'buffer_overflow': False,
            'timestep_falha': None,
            'historico_timesteps': []
        }
        
        # Inicializar arquivo de eventos
        with open(self.eventos_file, 'w') as f:
            f.write(f"=== LOG DE EVENTOS - {datetime.now()} ===\n\n")
    
    def log_evento(self, timestep: int, tipo: str, mensagem: str):
        """Registra um evento no buffer (otimizado - apenas eventos críticos)"""
        # Logar apenas eventos importantes para reduzir overhead
        if tipo in ['BUFFER_OVERFLOW', 'FALHA']:
            evento = f"[T{timestep:07d}] [{tipo}] {mensagem}"
            self.eventos_buffer.append(evento)
    
    def flush_eventos(self):
        """Escreve eventos do buffer no arquivo"""
        if self.eventos_buffer:
            with open(self.eventos_file, 'a') as f:
                f.write('\n'.join(self.eventos_buffer) + '\n')
            self.eventos_buffer.clear()
    
    def log_atendente_adicionado(self, timestep: int, servidor_id: str, atendente_id: str, tipo: str):
        """Registra adição de atendente"""
        self.log_evento(timestep, 'ATENDENTE_ADD', 
                       f"Atendente {atendente_id} ({tipo}) adicionado ao Servidor {servidor_id}")
        self.metricas['atendentes_adicionados'] += 1
    
    def log_atendente_removido(self, timestep: int, servidor_id: str, atendente_id: str, tipo: str):
        """Registra remoção de atendente"""
        self.log_evento(timestep, 'ATENDENTE_REM', 
                       f"Atendente {atendente_id} ({tipo}) removido do Servidor {servidor_id} (falha)")
        self.metricas['atendentes_removidos'] += 1
    
    def log_falha_atendente(self, timestep: int, servidor_id: str, atendente_id: str, tipo: str, solicitacao_id: int):
        """Registra falha de atendente"""
        self.log_evento(timestep, 'FALHA', 
                       f"Atendente {atendente_id} ({tipo}) do Servidor {servidor_id} falhou ao processar Solicitação {solicitacao_id}")
        self.metricas['total_falhas'] += 1
    
    def log_redirecionamento(self, timestep: int, solicitacao_id: int, origem: str, destino: str, tipo: str):
        """Registra redirecionamento de solicitação"""
        self.log_evento(timestep, 'REDIRECIONAR', 
                       f"Solicitação {solicitacao_id} ({tipo}) redirecionada de Servidor {origem} para Servidor {destino}")
        self.metricas['total_redirecionamentos'] += 1
    
    def log_buffer_overflow(self, timestep: int, servidor_id: str):
        """Registra estouro de buffer"""
        self.log_evento(timestep, 'BUFFER_OVERFLOW', 
                       f"Buffer do Servidor {servidor_id} estourou! Encerrando simulação.")
        self.metricas['buffer_overflow'] = True
        self.metricas['timestep_falha'] = timestep
    
    def log_timestep(self, timestep: int, stats: Dict):
        """Registra estatísticas de um timestep"""
        self.metricas['timesteps_executados'] = timestep
        self.metricas['total_solicitacoes'] += stats.get('solicitacoes_geradas', 0)
        self.metricas['total_atendimentos'] += stats.get('atendimentos_realizados', 0)
        
        # Adicionar ao histórico (amostragem)
        self.metricas['historico_timesteps'].append({
            'timestep': timestep,
            'solicitacoes': stats.get('solicitacoes_geradas', 0),
            'atendimentos': stats.get('atendimentos_realizados', 0),
            'falhas': stats.get('falhas', 0),
            'buffer_suporte_total': stats.get('buffer_suporte_total', 0),
            'buffer_vendas_total': stats.get('buffer_vendas_total', 0),
            'servidores': stats.get('servidores', {})
        })
    
    def salvar_metricas(self):
        """Salva métricas em arquivo JSON"""
        with open(self.metricas_file, 'w') as f:
            json.dump(self.metricas, f, indent=2)
    
    def get_metricas(self) -> Dict:
        """Retorna métricas atuais"""
        return self.metricas.copy()
    
    def finalizar(self):
        """Finaliza o logging"""
        self.flush_eventos()
        self.salvar_metricas()
        
        with open(self.eventos_file, 'a') as f:
            f.write(f"\n=== FIM DA SIMULAÇÃO - {datetime.now()} ===\n")
