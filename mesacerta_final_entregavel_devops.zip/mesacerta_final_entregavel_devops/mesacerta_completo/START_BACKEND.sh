#!/bin/bash

echo "========================================"
echo "  MESACERTA - Iniciando Backend"
echo "========================================"
echo ""

cd backend

echo "Verificando dependências..."
if [ ! -d "node_modules" ]; then
    echo "Instalando dependências pela primeira vez..."
    npm install
fi

echo ""
echo "Iniciando servidor backend..."
echo "Backend estará disponível em: http://localhost:3000"
echo ""
echo "IMPORTANTE: Mantenha esta janela aberta!"
echo "Para parar o servidor, pressione Ctrl+C"
echo ""
echo "========================================"
echo ""

npm start
