# 🚀 COMO INICIAR O MESACERTA

## ⚠️ IMPORTANTE: Você precisa iniciar o BACKEND primeiro!

O erro "Erro ao carregar restaurantes. Verifique se o backend está rodando" aparece porque o backend não está ativo.

---

## 📝 Passo a Passo Simples

### **Passo 1: Iniciar o Backend** ⚡

#### **Windows:**
1. Dê **duplo clique** no arquivo: `START_BACKEND.bat`
2. Uma janela preta (terminal) vai abrir
3. Aguarde até ver: `🚀 Servidor rodando na porta 3000`
4. **NÃO FECHE ESTA JANELA!** Deixe aberta enquanto usa o sistema

#### **Mac/Linux:**
1. Abra o terminal nesta pasta
2. Execute: `./START_BACKEND.sh`
3. Aguarde até ver: `🚀 Servidor rodando na porta 3000`
4. **NÃO FECHE O TERMINAL!** Deixe aberto enquanto usa o sistema

**OU use o terminal manualmente:**
```bash
cd backend
npm install    # Apenas na primeira vez
npm start      # Sempre que quiser iniciar
```

---

### **Passo 2: Abrir o Frontend** 🌐

Agora que o backend está rodando, abra o frontend:

#### **Opção A - VS Code Live Server (Recomendado):**
1. Abra a pasta `frontend` no VS Code
2. Clique com botão direito em `index.html`
3. Selecione **"Open with Live Server"**
4. O navegador abrirá automaticamente

#### **Opção B - Python:**
```bash
cd frontend
python -m http.server 8080
```
Depois abra: http://localhost:8080

#### **Opção C - Node.js:**
```bash
cd frontend
npx http-server -p 8080
```
Depois abra: http://localhost:8080

---

## ✅ Como Saber se Está Funcionando

### Backend Funcionando ✓
Você verá no terminal:
```
🚀 Servidor rodando na porta 3000
📡 API disponível em http://localhost:3000/api
✅ Conectado ao banco de dados SQLite
✅ Tabela users criada/verificada
✅ Tabela restaurants criada/verificada
✅ Tabela reservations criada/verificada
✅ Restaurante "Restaurante Italiano" inserido
✅ Restaurante "Sushi Bar" inserido
✅ Restaurante "Churrasqueira Premium" inserido
✅ Restaurante "Bistro Francês" inserido
```

### Frontend Funcionando ✓
- O site abre no navegador
- Você vê os restaurantes com imagens
- Não aparece erro de "backend não está rodando"

---

## 🔧 Resolver Problemas

### ❌ Erro: "Erro ao carregar restaurantes"

**Causa:** Backend não está rodando

**Solução:**
1. Abra o terminal/cmd
2. Vá para a pasta `backend`
3. Execute: `npm start`
4. Aguarde o servidor iniciar
5. Atualize a página do frontend (F5)

---

### ❌ Erro: "npm não é reconhecido"

**Causa:** Node.js não está instalado

**Solução:**
1. Baixe e instale o Node.js: https://nodejs.org
2. Reinicie o terminal
3. Tente novamente

---

### ❌ Erro: "Porta 3000 já está em uso"

**Causa:** Outro programa está usando a porta 3000

**Solução 1 - Fechar o processo:**
- **Windows:** Abra o Gerenciador de Tarefas e feche processos do Node.js
- **Mac/Linux:** Execute: `killall node`

**Solução 2 - Usar outra porta:**
1. Abra `backend/server.js`
2. Mude a linha: `const PORT = process.env.PORT || 3000;`
3. Para: `const PORT = process.env.PORT || 3001;`
4. Abra `frontend/js/api.js`
5. Mude: `const API_URL = 'http://localhost:3000/api';`
6. Para: `const API_URL = 'http://localhost:3001/api';`

---

### ❌ Erro de CORS

**Causa:** Você abriu o HTML diretamente do explorador de arquivos

**Solução:**
- Use Live Server no VS Code
- OU use Python/Node.js para servir o frontend
- **NÃO** abra o `index.html` diretamente clicando duas vezes

---

## 📋 Checklist Rápido

Antes de usar o sistema, verifique:

- [ ] Node.js está instalado (`node --version`)
- [ ] Dependências foram instaladas (`npm install` na pasta backend)
- [ ] Backend está rodando (terminal aberto com mensagem de sucesso)
- [ ] Frontend está sendo servido via HTTP (Live Server ou Python)
- [ ] Navegador está aberto em `http://localhost:8080` (ou porta do Live Server)

---

## 🎯 Fluxo Completo de Uso

```
1. Abrir Terminal → cd backend → npm start
   ↓
2. Aguardar mensagem "Servidor rodando"
   ↓
3. Abrir VS Code → frontend → index.html → Live Server
   ↓
4. Navegador abre automaticamente
   ↓
5. Usar o sistema normalmente
   ↓
6. Quando terminar: Fechar navegador e pressionar Ctrl+C no terminal
```

---

## 💡 Dicas

- **Primeira vez:** Execute `npm install` na pasta backend antes de iniciar
- **Desenvolvimento:** Use `nodemon` para reiniciar automaticamente:
  ```bash
  npm install -g nodemon
  nodemon backend/server.js
  ```
- **Depuração:** Abra o Console do navegador (F12) para ver erros
- **Teste da API:** Acesse http://localhost:3000/api/health no navegador

---

## 📞 Ainda com Problemas?

1. Verifique se o backend está realmente rodando
2. Abra http://localhost:3000/api/health no navegador
3. Se aparecer `{"status":"OK"...}` → Backend OK
4. Se não aparecer nada → Backend não está rodando
5. Leia os logs no terminal do backend para identificar erros

---

**Versão:** 2.0  
**Atualizado:** Outubro 2025
