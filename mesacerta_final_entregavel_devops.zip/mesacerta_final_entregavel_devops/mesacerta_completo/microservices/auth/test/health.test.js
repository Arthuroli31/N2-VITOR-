const request = require('supertest');
const expect = require('chai').expect;
const app = require('../server'); // Assumindo que server.js exporta o app Express

describe('Health Check', () => {
    it('deve retornar status 200 e status OK', (done) => {
        request(app)
            .get('/api/health')
            .expect(200)
            .end((err, res) => {
                if (err) return done(err);
                expect(res.body).to.be.an('object');
                expect(res.body.status).to.equal('OK');
                expect(res.body.message).to.include('Microserviço de Autenticação funcionando');
                done();
            });
    });
});
