# MESACERTA - Sistema de Reservas de Restaurantes

## Correções Implementadas

### Problema Identificado
O formulário de login estava a recarregar a página ao ser submetido, impedindo o processo de autenticação.

### Soluções Aplicadas

1. **Função handleLogin()**
   - Adicionado parâmetro `e` (evento) à função
   - Implementado `e.preventDefault()` para prevenir o comportamento padrão do formulário
   - Adicionada validação de campos vazios
   - Implementada limpeza do formulário após login bem-sucedido
   - Adicionado `return false` para garantir que o formulário não seja submetido

2. **Função handleRegister()**
   - Adicionado parâmetro `e` (evento) à função
   - Implementado `e.preventDefault()` para prevenir o comportamento padrão do formulário
   - Adicionadas validações adicionais:
     - Verificação de campos vazios
     - Validação de tamanho mínimo da senha (6 caracteres)
   - Implementada limpeza do formulário após registo bem-sucedido
   - Adicionado `return false` para garantir que o formulário não seja submetido

3. **Função handleReservation()**
   - Adicionado parâmetro `e` (evento) à função
   - Implementado `e.preventDefault()` para prevenir o comportamento padrão do formulário
   - Adicionada validação de data e horário
   - Implementada limpeza do formulário após reserva bem-sucedida
   - Adicionado `return false` para garantir que o formulário não seja submetido

## Como Usar

### Credenciais de Teste
Para testar o sistema de login, utilize as seguintes credenciais:

- **Email:** user@example.com
- **Senha:** 123456

### Funcionalidades

1. **Página Inicial**
   - Visualização de restaurantes em destaque
   - Botão para explorar todos os restaurantes

2. **Página de Restaurantes**
   - Busca por nome, culinária ou descrição
   - Filtro por tipo de culinária
   - Visualização de detalhes do restaurante
   - Sistema de reservas

3. **Página de Reservas**
   - Visualização de todas as reservas do utilizador
   - Cancelamento de reservas pendentes
   - Estados: Confirmada, Pendente, Cancelada, Concluída

4. **Sistema de Autenticação**
   - Login de utilizadores
   - Registo de novos utilizadores
   - Validação de formulários

## Estrutura de Arquivos

```
MESACERTA_WEBAPP/
├── index.html          # Página principal
├── css/
│   └── style.css      # Estilos da aplicação
├── js/
│   └── app.js         # Lógica da aplicação (CORRIGIDO)
├── img/               # Imagens dos restaurantes
├── README.md          # Documentação original
└── INSTRUCOES.md      # Este arquivo
```

## Tecnologias Utilizadas

- HTML5
- CSS3
- JavaScript (Vanilla)
- Bootstrap 5.3.0
- Font Awesome 6.4.0

## Notas Importantes

- Este é um protótipo com dados simulados
- **As imagens dos restaurantes são reais e de alta qualidade**
- A autenticação é simulada (não há backend real)
- As reservas são armazenadas apenas na memória do navegador
- Imagens incluídas:
  - Restaurante Italiano: Interior elegante com design moderno
  - Sushi Bar: Ambiente japonês autêntico
  - Churrasqueira Premium: Churrascaria brasileira sofisticada
  - Bistro Francês: Ambiente francês refinado

## Próximos Passos Sugeridos

1. Implementar backend real com API REST
2. Adicionar base de dados para persistência
3. Implementar autenticação JWT
4. Adicionar upload de imagens reais dos restaurantes
5. Implementar sistema de notificações por email
6. Adicionar integração com mapas para localização
7. Implementar sistema de avaliações e comentários

---

**Versão:** 1.1 (Corrigida)  
**Data:** Outubro 2025  
**Desenvolvido por:** MESACERTA Team
