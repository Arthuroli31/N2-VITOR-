// Configuração da API
const API_URL = '/api'; // O Nginx fará o roteamento correto para os microserviços

// Gerenciamento de token
const TokenManager = {
    set: (token) => {
        localStorage.setItem('mesacerta_token', token);
    },
    
    get: () => {
        return localStorage.getItem('mesacerta_token');
    },
    
    remove: () => {
        localStorage.removeItem('mesacerta_token');
    },
    
    isValid: () => {
        return !!TokenManager.get();
    }
};

// Gerenciamento de usuário
const UserManager = {
    set: (user) => {
        localStorage.setItem('mesacerta_user', JSON.stringify(user));
    },
    
    get: () => {
        const user = localStorage.getItem('mesacerta_user');
        return user ? JSON.parse(user) : null;
    },
    
    remove: () => {
        localStorage.removeItem('mesacerta_user');
    }
};

// Função auxiliar para fazer requisições
async function apiRequest(endpoint, options = {}) {
    const url = `${API_URL}${endpoint}`;
    
    const config = {
        ...options,
        headers: {
            'Content-Type': 'application/json',
            ...options.headers
        }
    };
    
    // Adicionar token se existir
    const token = TokenManager.get();
    if (token) {
        config.headers['Authorization'] = `Bearer ${token}`;
    }
    
    try {
        const response = await fetch(url, config);
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || 'Erro na requisição');
        }
        
        return data;
    } catch (error) {
        console.error('Erro na API:', error);
        throw error;
    }
}

// ==================== API DE AUTENTICAÇÃO ====================

const AuthAPI = {
    // Registrar novo usuário
    register: async (userData) => {
        return await apiRequest('/auth/register', {
            method: 'POST',
            body: JSON.stringify(userData)
        });
    },
    
    // Fazer login
    login: async (credentials) => {
        const data = await apiRequest('/auth/login', {
            method: 'POST',
            body: JSON.stringify(credentials)
        });
        
        // Salvar token e usuário
        if (data.token) {
            TokenManager.set(data.token);
            UserManager.set(data.user);
        }
        
        return data;
    },
    
    // Fazer logout
    logout: () => {
        TokenManager.remove();
        UserManager.remove();
    },
    
    // Obter usuário atual
    getCurrentUser: async () => {
        return await apiRequest('/auth/me');
    },
    
    // Verificar se está logado
    isLoggedIn: () => {
        return TokenManager.isValid() && UserManager.get() !== null;
    },
    
    // Obter usuário do localStorage
    getUser: () => {
        return UserManager.get();
    }
};

// ==================== API DE RESTAURANTES ====================

const RestaurantsAPI = {
    // Listar todos os restaurantes
    getAll: async (filters = {}) => {
        const params = new URLSearchParams();
        
        if (filters.search) {
            params.append('search', filters.search);
        }
        
        if (filters.cuisine && filters.cuisine !== 'all') {
            params.append('cuisine', filters.cuisine);
        }
        
        const queryString = params.toString();
        const endpoint = queryString ? `/restaurants?${queryString}` : '/restaurants';
        
        return await apiRequest(endpoint);
    },
    
    // Obter detalhes de um restaurante
    getById: async (id) => {
        return await apiRequest(`/restaurants/${id}`);
    },
    
    // Criar restaurante (admin)
    create: async (restaurantData) => {
        return await apiRequest('/restaurants', {
            method: 'POST',
            body: JSON.stringify(restaurantData)
        });
    },
    
    // Atualizar restaurante (admin)
    update: async (id, restaurantData) => {
        return await apiRequest(`/restaurants/${id}`, {
            method: 'PUT',
            body: JSON.stringify(restaurantData)
        });
    },
    
    // Deletar restaurante (admin)
    delete: async (id) => {
        return await apiRequest(`/restaurants/${id}`, {
            method: 'DELETE'
        });
    }
};

// ==================== API DE RESERVAS ====================

const ReservationsAPI = {
    // Criar nova reserva
    create: async (reservationData) => {
        return await apiRequest('/reservations', {
            method: 'POST',
            body: JSON.stringify(reservationData)
        });
    },
    
    // Listar reservas do usuário
    getAll: async () => {
        return await apiRequest('/reservations');
    },
    
    // Obter detalhes de uma reserva
    getById: async (id) => {
        return await apiRequest(`/reservations/${id}`);
    },
    
    // Atualizar reserva
    update: async (id, reservationData) => {
        return await apiRequest(`/reservations/${id}`, {
            method: 'PUT',
            body: JSON.stringify(reservationData)
        });
    },
    
    // Cancelar reserva
    cancel: async (id) => {
        return await apiRequest(`/reservations/${id}`, {
            method: 'DELETE'
        });
    }
};

// ==================== API DE SAÚDE ====================

const HealthAPI = {
    check: async () => {
        return await apiRequest('/health');
    }
};
