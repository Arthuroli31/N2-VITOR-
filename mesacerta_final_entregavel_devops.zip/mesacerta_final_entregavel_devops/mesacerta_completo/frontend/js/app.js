// Estado da aplicação
let appState = {
    currentPage: 'home',
    isLoggedIn: false,
    currentUser: null,
    selectedRestaurant: null,
    restaurants: [],
    reservations: []
};

// Elementos DOM
const pages = document.querySelectorAll('.page');
const navLinks = document.querySelectorAll('.nav-link');
const loginBtn = document.getElementById('login-btn');
const registerBtn = document.getElementById('register-btn');
const loginModal = new bootstrap.Modal(document.getElementById('login-modal'));
const registerModal = new bootstrap.Modal(document.getElementById('register-modal'));
const restaurantModal = new bootstrap.Modal(document.getElementById('restaurant-modal'));
const loginForm = document.getElementById('login-form');
const registerForm = document.getElementById('register-form');
const reservationForm = document.getElementById('reservation-form');
const exploreBtn = document.getElementById('explore-btn');
const featuredRestaurantsContainer = document.getElementById('featured-restaurants');
const restaurantsListContainer = document.getElementById('restaurants-list');
const reservationsListContainer = document.getElementById('reservations-list');
const loginAlert = document.getElementById('login-alert');
const searchInput = document.getElementById('search-input');
const searchBtn = document.getElementById('search-btn');
const cuisineFilter = document.getElementById('cuisine-filter');
const registerLink = document.getElementById('register-link');
const loginLink = document.getElementById('login-link');

// Inicialização
document.addEventListener('DOMContentLoaded', async () => {
    // Verificar se o usuário está logado
    await checkLoginStatus();
    
    // Carregar restaurantes
    await loadAllRestaurants();
    
    // Carregar restaurantes em destaque
    loadFeaturedRestaurants();
    
    // Configurar eventos
    setupEventListeners();
});

// Verificar status de login
async function checkLoginStatus() {
    if (AuthAPI.isLoggedIn()) {
        const user = AuthAPI.getUser();
        if (user) {
            appState.isLoggedIn = true;
            appState.currentUser = user;
            updateUIForLoggedInUser();
        }
    }
}

// Atualizar UI para usuário logado
function updateUIForLoggedInUser() {
    loginBtn.textContent = 'Minha Conta';
    registerBtn.textContent = 'Sair';
    registerBtn.onclick = handleLogout;
}

// Carregar todos os restaurantes da API
async function loadAllRestaurants(filters = {}) {
    try {
        const data = await RestaurantsAPI.getAll(filters);
        appState.restaurants = data.restaurants;
        loadRestaurants();
    } catch (error) {
        console.error('Erro ao carregar restaurantes:', error);
        alert('Erro ao carregar restaurantes. Verifique se o backend está rodando.');
    }
}

// Carregar restaurantes em destaque
function loadFeaturedRestaurants() {
    featuredRestaurantsContainer.innerHTML = '';
    
    // Selecionar 3 restaurantes aleatórios
    const featured = [...appState.restaurants]
        .sort(() => 0.5 - Math.random())
        .slice(0, 3);
    
    featured.forEach(restaurant => {
        const restaurantCard = createRestaurantCard(restaurant);
        featuredRestaurantsContainer.appendChild(restaurantCard);
    });
}

// Carregar lista de restaurantes
function loadRestaurants() {
    restaurantsListContainer.innerHTML = '';
    
    if (appState.restaurants.length === 0) {
        restaurantsListContainer.innerHTML = `
            <div class="col-12">
                <div class="alert alert-info">
                    Nenhum restaurante encontrado.
                </div>
            </div>
        `;
        return;
    }
    
    appState.restaurants.forEach(restaurant => {
        const restaurantCard = createRestaurantCard(restaurant);
        restaurantsListContainer.appendChild(restaurantCard);
    });
}

// Criar card de restaurante
function createRestaurantCard(restaurant) {
    const col = document.createElement('div');
    col.className = 'col-md-4 mb-4';
    
    const stars = generateRatingStars(restaurant.rating);
    const statusClass = restaurant.is_open ? 'status-open' : 'status-closed';
    const statusText = restaurant.is_open ? 'Aberto' : 'Fechado';
    
    col.innerHTML = `
        <div class="card restaurant-card h-100">
            <img src="${restaurant.image_url}" class="card-img-top restaurant-image" alt="${restaurant.name}">
            <div class="card-body">
                <h5 class="card-title">${restaurant.name}</h5>
                <p class="card-text restaurant-cuisine">${restaurant.cuisine} • ${restaurant.price_range}</p>
                <div class="restaurant-rating">
                    <div class="rating-stars">${stars}</div>
                    <span>${restaurant.rating}</span>
                </div>
                <p class="card-text">${restaurant.address}</p>
                <div class="d-flex justify-content-between align-items-center">
                    <span class="restaurant-status ${statusClass}">${statusText}</span>
                    <button class="btn btn-sm btn-outline-primary reserve-btn" data-id="${restaurant.id}">Reservar</button>
                </div>
            </div>
        </div>
    `;
    
    col.querySelector('.reserve-btn').addEventListener('click', () => {
        openRestaurantModal(restaurant);
    });
    
    return col;
}

// Gerar estrelas de avaliação
function generateRatingStars(rating) {
    const fullStars = Math.floor(rating);
    const halfStar = rating % 1 >= 0.5;
    const emptyStars = 5 - fullStars - (halfStar ? 1 : 0);
    
    let starsHTML = '';
    
    for (let i = 0; i < fullStars; i++) {
        starsHTML += '<i class="fas fa-star"></i>';
    }
    
    if (halfStar) {
        starsHTML += '<i class="fas fa-star-half-alt"></i>';
    }
    
    for (let i = 0; i < emptyStars; i++) {
        starsHTML += '<i class="far fa-star"></i>';
    }
    
    return starsHTML;
}

// Carregar reservas do usuário
async function loadReservations() {
    if (!appState.isLoggedIn) {
        loginAlert.classList.remove('d-none');
        reservationsListContainer.classList.add('d-none');
        return;
    }
    
    loginAlert.classList.add('d-none');
    reservationsListContainer.classList.remove('d-none');
    
    try {
        const data = await ReservationsAPI.getAll();
        appState.reservations = data.reservations;
        
        reservationsListContainer.innerHTML = '';
        
        if (appState.reservations.length === 0) {
            reservationsListContainer.innerHTML = `
                <div class="alert alert-info">
                    Você ainda não tem reservas.
                </div>
            `;
            return;
        }
        
        appState.reservations.forEach(reservation => {
            const statusClass = getStatusClass(reservation.status);
            const statusText = getStatusText(reservation.status);
            
            const reservationCard = document.createElement('div');
            reservationCard.className = `card reservation-card ${reservation.status} mb-3`;
            
            reservationCard.innerHTML = `
                <div class="reservation-header">
                    <h5 class="mb-0">${reservation.restaurant_name}</h5>
                    <span class="reservation-status ${statusClass}">${statusText}</span>
                </div>
                <div class="reservation-body">
                    <div class="row">
                        <div class="col-md-6">
                            <p><i class="far fa-calendar-alt"></i> Data: ${formatDate(reservation.date)}</p>
                            <p><i class="far fa-clock"></i> Horário: ${reservation.time}</p>
                            <p><i class="fas fa-users"></i> Pessoas: ${reservation.guests}</p>
                        </div>
                        <div class="col-md-6">
                            <p><i class="fas fa-map-marker-alt"></i> ${reservation.restaurant_address}</p>
                            <p><i class="fas fa-comment-alt"></i> Observações: ${reservation.special_requests || 'Nenhuma'}</p>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end mt-3">
                        ${reservation.status === 'pending' ? `
                            <button class="btn btn-sm btn-danger cancel-btn" data-id="${reservation.id}">Cancelar</button>
                        ` : ''}
                    </div>
                </div>
            `;
            
            if (reservation.status === 'pending') {
                const cancelBtn = reservationCard.querySelector('.cancel-btn');
                cancelBtn.addEventListener('click', () => cancelReservation(reservation.id));
            }
            
            reservationsListContainer.appendChild(reservationCard);
        });
    } catch (error) {
        console.error('Erro ao carregar reservas:', error);
        reservationsListContainer.innerHTML = `
            <div class="alert alert-danger">
                Erro ao carregar reservas. Por favor, tente novamente.
            </div>
        `;
    }
}

// Obter classe CSS para status
function getStatusClass(status) {
    const classes = {
        'confirmed': 'status-confirmed',
        'pending': 'status-pending',
        'cancelled': 'status-cancelled',
        'completed': 'status-confirmed'
    };
    return classes[status] || '';
}

// Obter texto para status
function getStatusText(status) {
    const texts = {
        'confirmed': 'Confirmada',
        'pending': 'Pendente',
        'cancelled': 'Cancelada',
        'completed': 'Concluída'
    };
    return texts[status] || status;
}

// Formatar data
function formatDate(dateString) {
    const date = new Date(dateString + 'T00:00:00');
    return date.toLocaleDateString('pt-PT');
}

// Abrir modal de restaurante
function openRestaurantModal(restaurant) {
    appState.selectedRestaurant = restaurant;
    
    document.getElementById('restaurant-name').textContent = restaurant.name;
    document.getElementById('restaurant-image').src = restaurant.image_url;
    document.getElementById('restaurant-rating').innerHTML = generateRatingStars(restaurant.rating);
    document.getElementById('restaurant-cuisine').textContent = `${restaurant.cuisine} • ${restaurant.price_range}`;
    document.getElementById('restaurant-address').innerHTML = `<i class="fas fa-map-marker-alt"></i> ${restaurant.address}`;
    document.getElementById('restaurant-description').textContent = restaurant.description;
    
    const openStatusEl = document.getElementById('restaurant-open-status');
    if (restaurant.is_open) {
        openStatusEl.innerHTML = '<span class="badge bg-success">Aberto</span>';
    } else {
        openStatusEl.innerHTML = '<span class="badge bg-danger">Fechado</span>';
    }
    
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('reservation-date').min = today;
    
    restaurantModal.show();
}

// Cancelar reserva
async function cancelReservation(reservationId) {
    if (!confirm('Tem certeza que deseja cancelar esta reserva?')) {
        return;
    }
    
    try {
        await ReservationsAPI.cancel(reservationId);
        alert('Reserva cancelada com sucesso!');
        await loadReservations();
    } catch (error) {
        console.error('Erro ao cancelar reserva:', error);
        alert('Erro ao cancelar reserva. Por favor, tente novamente.');
    }
}

// Configurar eventos
function setupEventListeners() {
    // Navegação
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const targetPage = link.id.split('-')[0];
            navigateTo(targetPage);
        });
    });
    
    // Botão Explorar
    exploreBtn.addEventListener('click', () => {
        navigateTo('restaurants');
    });
    
    // Login e Registro
    loginBtn.addEventListener('click', () => {
        loginModal.show();
    });
    
    registerBtn.addEventListener('click', () => {
        if (appState.isLoggedIn) {
            handleLogout();
        } else {
            registerModal.show();
        }
    });
    
    registerLink.addEventListener('click', (e) => {
        e.preventDefault();
        loginModal.hide();
        setTimeout(() => registerModal.show(), 500);
    });
    
    loginLink.addEventListener('click', (e) => {
        e.preventDefault();
        registerModal.hide();
        setTimeout(() => loginModal.show(), 500);
    });
    
    // Formulários
    loginForm.addEventListener('submit', handleLogin);
    registerForm.addEventListener('submit', handleRegister);
    reservationForm.addEventListener('submit', handleReservation);
    
    // Pesquisa e filtros
    searchBtn.addEventListener('click', handleSearch);
    searchInput.addEventListener('keyup', (e) => {
        if (e.key === 'Enter') {
            handleSearch();
        }
    });
    cuisineFilter.addEventListener('change', handleSearch);
}

// Navegar para página
function navigateTo(page) {
    appState.currentPage = page;
    
    navLinks.forEach(link => {
        if (link.id === `${page}-link`) {
            link.classList.add('active');
        } else {
            link.classList.remove('active');
        }
    });
    
    pages.forEach(p => {
        if (p.id === `${page}-page`) {
            p.classList.add('active');
        } else {
            p.classList.remove('active');
        }
    });
    
    if (page === 'reservations') {
        loadReservations();
    }
}

// Manipular login
async function handleLogin(e) {
    e.preventDefault();
    
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    
    if (!email || !password) {
        alert('Por favor, preencha todos os campos!');
        return;
    }
    
    try {
        const data = await AuthAPI.login({ email, password });
        
        appState.isLoggedIn = true;
        appState.currentUser = data.user;
        
        updateUIForLoggedInUser();
        loginModal.hide();
        loginForm.reset();
        
        alert(`Bem-vindo, ${data.user.name}!`);
    } catch (error) {
        console.error('Erro no login:', error);
        alert(error.message || 'Email ou senha incorretos!');
    }
}

// Manipular registro
async function handleRegister(e) {
    e.preventDefault();
    
    const name = document.getElementById('register-name').value;
    const email = document.getElementById('register-email').value;
    const phone = document.getElementById('register-phone').value;
    const password = document.getElementById('register-password').value;
    const confirmPassword = document.getElementById('register-confirm-password').value;
    
    if (!name || !email || !phone || !password || !confirmPassword) {
        alert('Por favor, preencha todos os campos!');
        return;
    }
    
    if (password !== confirmPassword) {
        alert('As senhas não coincidem!');
        return;
    }
    
    if (password.length < 6) {
        alert('A senha deve ter pelo menos 6 caracteres!');
        return;
    }
    
    try {
        await AuthAPI.register({ name, email, phone, password });
        
        alert(`Conta criada com sucesso para ${name}!`);
        registerModal.hide();
        registerForm.reset();
        
        setTimeout(() => loginModal.show(), 500);
    } catch (error) {
        console.error('Erro no registro:', error);
        alert(error.message || 'Erro ao criar conta. Por favor, tente novamente.');
    }
}

// Manipular logout
function handleLogout() {
    if (confirm('Deseja realmente sair?')) {
        AuthAPI.logout();
        appState.isLoggedIn = false;
        appState.currentUser = null;
        
        loginBtn.textContent = 'Login';
        registerBtn.textContent = 'Registrar';
        registerBtn.onclick = () => registerModal.show();
        
        navigateTo('home');
        alert('Logout realizado com sucesso!');
    }
}

// Manipular reserva
async function handleReservation(e) {
    e.preventDefault();
    
    if (!appState.isLoggedIn) {
        alert('Faça login para realizar uma reserva!');
        restaurantModal.hide();
        setTimeout(() => loginModal.show(), 500);
        return;
    }
    
    const date = document.getElementById('reservation-date').value;
    const time = document.getElementById('reservation-time').value;
    const guests = parseInt(document.getElementById('reservation-guests').value);
    const notes = document.getElementById('reservation-notes').value;
    
    if (!date || !time) {
        alert('Por favor, selecione a data e o horário!');
        return;
    }
    
    try {
        await ReservationsAPI.create({
            restaurant_id: appState.selectedRestaurant.id,
            date,
            time,
            guests,
            special_requests: notes
        });
        
        restaurantModal.hide();
        reservationForm.reset();
        
        alert('Reserva realizada com sucesso! Aguarde a confirmação do restaurante.');
        navigateTo('reservations');
    } catch (error) {
        console.error('Erro ao criar reserva:', error);
        alert(error.message || 'Erro ao criar reserva. Por favor, tente novamente.');
    }
}

// Manipular pesquisa
async function handleSearch() {
    const searchTerm = searchInput.value.trim();
    const cuisine = cuisineFilter.value;
    
    await loadAllRestaurants({
        search: searchTerm,
        cuisine: cuisine
    });
}
