import http from 'k6/http';
import { check, sleep } from 'k6';

// Configurações do teste de carga
// O teste será executado contra o frontend (Nginx) que fará o proxy para os microserviços.
// O endereço do Nginx é 'frontend' dentro da rede Docker.
// Como o K6 será executado *fora* do docker-compose, precisamos usar o endereço externo.
// Para simular o ambiente, vamos usar um endereço de host que será resolvido para o container 'frontend'.
// Em um ambiente real, seria o IP ou domínio do load balancer.
// Para este teste, vamos assumir que o serviço 'frontend' está acessível via 'localhost' na porta 80.
// No entanto, como o K6 será executado *dentro* do container, precisamos usar o nome do serviço.
// Vamos criar um serviço K6 no docker-compose para que ele possa acessar os outros serviços.

// Vamos reverter e usar o K6 diretamente no host, mas o teste será contra a porta 80 do frontend.
// Para que o K6 no host possa acessar os serviços do docker-compose, eles precisam estar expostos.
// O frontend está exposto na porta 80.

export const options = {
    // Cenários de carga:
    // 10 req/s (leve) -> 10 VUs, duração 30s
    // 50 req/s (médio) -> 50 VUs, duração 30s
    // 100 req/s (popular) -> 100 VUs, duração 30s
    // 1000 req/s (viral) -> 500 VUs, duração 30s (assumindo 2 req/s por VU)

    scenarios: {
        leve: {
            executor: 'constant-vus',
            vus: 10,
            duration: '30s',
            tags: { test_type: 'leve' },
        },
        medio: {
            executor: 'constant-vus',
            vus: 50,
            duration: '30s',
            tags: { test_type: 'medio' },
        },
        popular: {
            executor: 'constant-vus',
            vus: 100,
            duration: '30s',
            tags: { test_type: 'popular' },
        },
        viral: {
            executor: 'constant-vus',
            vus: 500,
            duration: '30s',
            tags: { test_type: 'viral' },
        },
    },
    thresholds: {
        // Taxa de erro deve ser menor que 1%
        'http_req_failed{test_type:leve}': ['rate<0.01'],
        'http_req_failed{test_type:medio}': ['rate<0.05'], // Tolerância maior para carga média
        'http_req_failed{test_type:popular}': ['rate<0.10'], // Tolerância maior para carga popular
        'http_req_failed{test_type:viral}': ['rate<0.20'], // Tolerância maior para carga viral

        // 95% das requisições devem ser concluídas em 500ms (leve)
        'http_req_duration{test_type:leve}': ['p(95)<500'],
        // 95% das requisições devem ser concluídas em 1000ms (médio)
        'http_req_duration{test_type:medio}': ['p(95)<1000'],
        // 95% das requisições devem ser concluídas em 2000ms (popular)
        'http_req_duration{test_type:popular}': ['p(95)<2000'],
        // 95% das requisições devem ser concluídas em 5000ms (viral)
        'http_req_duration{test_type:viral}': ['p(95)<5000'],
    },
};

// URL base do frontend (Nginx)
const BASE_URL = 'http://localhost';

export default function () {
    // Simulação de acesso à página inicial e listagem de restaurantes (rota pública)
    let res = http.get(`${BASE_URL}/api/restaurants`);
    check(res, {
        'status is 200': (r) => r.status === 200,
        'response body is not empty': (r) => r.body.length > 0,
    });

    // Simulação de acesso a um restaurante específico (rota pública)
    res = http.get(`${BASE_URL}/api/restaurants/1`);
    check(res, {
        'status is 200': (r) => r.status === 200,
    });

    // Simulação de health check (rota pública)
    res = http.get(`${BASE_URL}/api/health`);
    check(res, {
        'status is 200': (r) => r.status === 200,
    });

    sleep(1); // Espera 1 segundo entre as iterações
}
