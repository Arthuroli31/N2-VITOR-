#!/usr/bin/env python3
"""
Exemplo de uso completo do Sistema de Produção
Demonstra como executar simulações com configurações completas
"""

from production_line import ProductionLine
from analyze_results import ProductionAnalyzer


def exemplo_configuracao_minima():
    """
    Executa simulação com configuração mínima exigida pelo projeto.
    
    Requisitos mínimos:
    - Buffer: 1000 itens
    - Produtores: 200
    - Consumidores: 220 (200 * 1.1)
    - Timesteps: 1.000.000
    """
    print("\n" + "="*80)
    print("EXEMPLO: CONFIGURAÇÃO MÍNIMA EXIGIDA")
    print("="*80)
    print("\nAVISO: Esta simulação pode levar vários minutos para completar.")
    print("Para teste rápido, use o toy problem em production_line.py\n")
    
    line = ProductionLine(
        buffer_capacity=1000,
        num_producers=200,
        num_consumers=220,
        total_timesteps=1000000,
        validate=True  # Valida os parâmetros mínimos
    )
    
    line.start()
    line.wait_completion()
    line.print_report()
    line.save_report("relatorio_configuracao_minima.json")
    
    return line


def exemplo_configuracao_otimizada():
    """
    Executa simulação com configuração otimizada para melhor desempenho.
    
    Usa buffer maior e mais consumidores para reduzir gargalos.
    """
    print("\n" + "="*80)
    print("EXEMPLO: CONFIGURAÇÃO OTIMIZADA")
    print("="*80)
    print("\nBuffer maior e mais consumidores para melhor throughput.\n")
    
    line = ProductionLine(
        buffer_capacity=5000,
        num_producers=200,
        num_consumers=250,
        total_timesteps=1000000,
        validate=True
    )
    
    line.start()
    line.wait_completion()
    line.print_report()
    line.save_report("relatorio_configuracao_otimizada.json")
    
    return line


def exemplo_analise_comparativa():
    """
    Carrega múltiplos relatórios e gera análise comparativa.
    """
    print("\n" + "="*80)
    print("ANÁLISE COMPARATIVA")
    print("="*80)
    
    analyzer = ProductionAnalyzer()
    
    # Carrega relatórios
    relatorios = [
        "relatorio_configuracao_minima.json",
        "relatorio_configuracao_otimizada.json"
    ]
    
    for relatorio in relatorios:
        try:
            analyzer.load_report(relatorio)
            print(f"✓ Carregado: {relatorio}")
        except FileNotFoundError:
            print(f"✗ Não encontrado: {relatorio}")
    
    if len(analyzer.reports) >= 2:
        print("\nGerando análises...")
        
        # Tabela comparativa
        df = analyzer.create_comparison_table()
        print("\n[TABELA COMPARATIVA]")
        print(df.to_string(index=False))
        df.to_csv("comparacao_configuracoes.csv", index=False)
        
        # Gráficos
        analyzer.plot_performance_comparison()
        analyzer.plot_buffer_capacity_impact()
        
        # Relatório completo
        analyzer.generate_full_report("analise_comparativa_completa.txt")
        
        print("\n✓ Análise concluída!")
        print("  - comparacao_configuracoes.csv")
        print("  - comparacao_desempenho.png")
        print("  - impacto_capacidade_buffer.png")
        print("  - analise_comparativa_completa.txt")
    else:
        print("\nNecessário pelo menos 2 relatórios para comparação.")


def main():
    """
    Função principal - escolha qual exemplo executar.
    """
    print("="*80)
    print("SISTEMA DE CONTROLE PARA LINHA DE PRODUÇÃO INDUSTRIAL")
    print("Exemplos de Uso Completo")
    print("="*80)
    
    print("\nEscolha uma opção:")
    print("1. Executar configuração mínima (leva ~5-10 minutos)")
    print("2. Executar configuração otimizada (leva ~5-10 minutos)")
    print("3. Executar ambas e comparar (leva ~10-20 minutos)")
    print("4. Apenas analisar relatórios existentes")
    print("5. Sair")
    
    try:
        opcao = input("\nOpção: ").strip()
        
        if opcao == "1":
            exemplo_configuracao_minima()
        elif opcao == "2":
            exemplo_configuracao_otimizada()
        elif opcao == "3":
            exemplo_configuracao_minima()
            exemplo_configuracao_otimizada()
            exemplo_analise_comparativa()
        elif opcao == "4":
            exemplo_analise_comparativa()
        elif opcao == "5":
            print("Saindo...")
        else:
            print("Opção inválida!")
    
    except KeyboardInterrupt:
        print("\n\nInterrompido pelo usuário.")
    except Exception as e:
        print(f"\nErro: {e}")


if __name__ == "__main__":
    # Para execução automática sem interação, descomente uma das linhas abaixo:
    
    # exemplo_configuracao_minima()
    # exemplo_configuracao_otimizada()
    # exemplo_analise_comparativa()
    
    # Para execução interativa:
    main()
