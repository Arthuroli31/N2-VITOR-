#!/usr/bin/env python3
"""
Script para executar múltiplos experimentos com diferentes configurações
e gerar análises comparativas
"""

from production_line import ProductionLine
from analyze_results import ProductionAnalyzer
import time


def run_experiment(name: str, buffer_capacity: int, num_producers: int, 
                   num_consumers: int, total_timesteps: int, validate: bool = False):
    """
    Executa um experimento com configuração específica.
    
    Args:
        name: Nome do experimento
        buffer_capacity: Capacidade do buffer
        num_producers: Número de produtores
        num_consumers: Número de consumidores
        total_timesteps: Total de timesteps
        validate: Se True, valida parâmetros mínimos
    
    Returns:
        Nome do arquivo de relatório gerado
    """
    print("\n" + "="*80)
    print(f"EXPERIMENTO: {name}")
    print("="*80)
    
    line = ProductionLine(
        buffer_capacity=buffer_capacity,
        num_producers=num_producers,
        num_consumers=num_consumers,
        total_timesteps=total_timesteps,
        validate=validate
    )
    
    line.start()
    line.wait_completion()
    line.print_report()
    
    filename = f"relatorio_{name.lower().replace(' ', '_')}.json"
    line.save_report(filename)
    
    return filename


def main():
    """Executa conjunto de experimentos"""
    
    print("="*80)
    print("SUITE DE EXPERIMENTOS - LINHA DE PRODUÇÃO INDUSTRIAL")
    print("="*80)
    
    start_time = time.time()
    report_files = []
    
    # Experimento 1: Toy Problem (teste rápido)
    report_files.append(run_experiment(
        name="Toy Problem",
        buffer_capacity=10,
        num_producers=2,
        num_consumers=3,
        total_timesteps=100
    ))
    
    # Experimento 2: Buffer pequeno
    report_files.append(run_experiment(
        name="Buffer Pequeno",
        buffer_capacity=1000,
        num_producers=200,
        num_consumers=220,
        total_timesteps=10000
    ))
    
    # Experimento 3: Buffer médio
    report_files.append(run_experiment(
        name="Buffer Medio",
        buffer_capacity=5000,
        num_producers=200,
        num_consumers=220,
        total_timesteps=10000
    ))
    
    # Experimento 4: Buffer grande
    report_files.append(run_experiment(
        name="Buffer Grande",
        buffer_capacity=10000,
        num_producers=200,
        num_consumers=220,
        total_timesteps=10000
    ))
    
    # Experimento 5: Mais consumidores
    report_files.append(run_experiment(
        name="Mais Consumidores",
        buffer_capacity=5000,
        num_producers=200,
        num_consumers=300,
        total_timesteps=10000
    ))
    
    # Experimento 6: Balanceado (comentado - execução longa)
    """
    report_files.append(run_experiment(
        name="Balanceado Completo",
        buffer_capacity=5000,
        num_producers=200,
        num_consumers=220,
        total_timesteps=1000000
    ))
    """
    
    total_time = time.time() - start_time
    
    print("\n" + "="*80)
    print("TODOS OS EXPERIMENTOS CONCLUÍDOS")
    print("="*80)
    print(f"Tempo total de execução: {total_time:.2f} segundos")
    print(f"Relatórios gerados: {len(report_files)}")
    
    # Análise comparativa
    print("\n" + "="*80)
    print("GERANDO ANÁLISE COMPARATIVA")
    print("="*80)
    
    analyzer = ProductionAnalyzer()
    
    for filename in report_files:
        try:
            analyzer.load_report(filename)
            print(f"  Carregado: {filename}")
        except FileNotFoundError:
            print(f"  Erro ao carregar: {filename}")
    
    # Gera tabela comparativa
    if analyzer.reports:
        df = analyzer.create_comparison_table()
        print("\n[TABELA COMPARATIVA]")
        print(df.to_string(index=False))
        
        # Salva tabela em CSV
        df.to_csv("comparacao_experimentos.csv", index=False)
        print("\nTabela salva em: comparacao_experimentos.csv")
        
        # Gera gráficos comparativos
        print("\nGerando gráficos comparativos...")
        analyzer.plot_performance_comparison()
        analyzer.plot_buffer_capacity_impact()
        
        # Gera relatório completo
        analyzer.generate_full_report("analise_completa_experimentos.txt")
        
        print("\n" + "="*80)
        print("ANÁLISE COMPLETA FINALIZADA")
        print("="*80)
        print("\nArquivos gerados:")
        print("  - comparacao_experimentos.csv")
        print("  - comparacao_desempenho.png")
        print("  - impacto_capacidade_buffer.png")
        print("  - analise_completa_experimentos.txt")
        print("  - relatorio_*.json (múltiplos)")


if __name__ == "__main__":
    main()
