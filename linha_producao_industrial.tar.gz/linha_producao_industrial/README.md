# Sistema de Controle para Linha de Produção Industrial

**Miniprojeto Distribuído N2 - Sistemas Distribuídos**

Este projeto implementa uma simulação de linha de produção industrial automatizada usando o padrão **Produtor-Consumidor** com threads, semáforos e mutex em Python.

## Descrição do Projeto

Em uma linha de produção industrial automatizada, peças precisam ser processadas em etapas sucessivas. Cada etapa representa uma operação, e o tempo de processamento varia dependendo da complexidade.

O objetivo deste projeto é criar uma simulação da linha de produção e coordenar os processos de entrada e saída das peças de cada etapa usando threads em um ambiente de programação multithread.

## Características Principais

### 1. Buffer (Fila de Processamento)
- Capacidade fixa configurável (mínimo 1000 itens)
- Armazena peças que aguardam processamento
- Implementado com sincronização thread-safe

### 2. Produtores
- Threads que adicionam peças ao buffer
- Bloqueiam quando o buffer está cheio
- Produtividade fixa por timestep
- Identificação automática e procedural

### 3. Consumidores
- Threads que retiram peças do buffer
- Bloqueiam quando o buffer está vazio
- Podem operar em paralelo com produtores
- Número mínimo: produtores + 10%

### 4. Sincronização
- **Semáforo de Espaço Disponível**: controla posições livres no buffer
- **Semáforo de Itens Disponíveis**: controla número de peças prontas
- **Mutex (Lock)**: garante acesso exclusivo ao buffer (evita race conditions)

## Estrutura dos Arquivos

```
.
├── production_line.py          # Implementação principal do sistema
├── analyze_results.py          # Análise e visualização de resultados
├── run_experiments.py          # Execução de múltiplos experimentos
├── README.md                   # Este arquivo
└── requisitos_projeto.md       # Análise dos requisitos
```

## Requisitos

### Python 3.7+

### Bibliotecas necessárias:
```bash
pip install matplotlib numpy pandas
```

Ou instale todas as dependências:
```bash
pip install -r requirements.txt
```

## Como Usar

### 1. Execução Simples (Toy Problem)

Execute o arquivo principal para testar com configuração reduzida:

```bash
python3 production_line.py
```

Isso executará um exemplo rápido com:
- Buffer: 10 itens
- Produtores: 2
- Consumidores: 3
- Timesteps: 100

### 2. Configuração Personalizada

Edite o arquivo `production_line.py` ou crie seu próprio script:

```python
from production_line import ProductionLine

# Cria linha de produção
line = ProductionLine(
    buffer_capacity=1000,      # Capacidade do buffer
    num_producers=200,         # Número de produtores
    num_consumers=220,         # Número de consumidores
    total_timesteps=1000000    # Total de ciclos
)

# Inicia simulação
line.start()
line.wait_completion()

# Exibe e salva relatório
line.print_report()
line.save_report("meu_relatorio.json")
```

### 3. Análise de Resultados

Após executar a simulação, analise os resultados:

```bash
python3 analyze_results.py
```

Isso gerará:
- Gráficos de evolução do buffer
- Comparação produção vs consumo
- Análise de tempos de espera
- Relatório textual completo

### 4. Múltiplos Experimentos

Execute uma suite completa de experimentos comparativos:

```bash
python3 run_experiments.py
```

Isso executará múltiplas configurações e gerará:
- Tabela comparativa (CSV)
- Gráficos de desempenho
- Análise de impacto da capacidade do buffer
- Relatório consolidado

## Parâmetros de Entrada

| Parâmetro | Descrição | Valor Mínimo |
|-----------|-----------|--------------|
| `buffer_capacity` | Capacidade máxima do buffer | 1000 |
| `num_producers` | Número de threads produtoras | 200 |
| `num_consumers` | Número de threads consumidoras | produtores × 1.1 |
| `total_timesteps` | Número total de ciclos de simulação | 1.000.000 |

## Saída Gerada

### Relatório JSON
Contém todas as estatísticas da simulação:
- Configuração utilizada
- Total produzido e consumido
- Itens restantes no buffer
- Esperas de produtores e consumidores
- Métricas de desempenho
- Snapshots do buffer ao longo do tempo

### Gráficos
- **Evolução do Buffer**: mostra ocupação do buffer ao longo do tempo
- **Produção vs Consumo**: comparação visual dos totais
- **Tempos de Espera**: análise de bloqueios
- **Comparação de Desempenho**: múltiplas configurações
- **Impacto da Capacidade**: análise de diferentes tamanhos de buffer

### Relatório Textual
Análise completa formatada com:
- Parâmetros de configuração
- Resultados detalhados
- Métricas de desempenho
- Análise de eficiência

## Exemplo de Saída

```
======================================================================
RELATÓRIO DA SIMULAÇÃO - LINHA DE PRODUÇÃO INDUSTRIAL
======================================================================

[CONFIGURAÇÃO]
  Capacidade do Buffer: 10
  Número de Produtores: 2
  Número de Consumidores: 3
  Total de Timesteps: 100

[RESULTADOS]
  Total Produzido: 100
  Total Consumido: 95
  Itens Restantes no Buffer: 5
  Esperas de Produtores: 12
  Esperas de Consumidores: 8

[DESEMPENHO]
  Tempo de Execução: 0.15 segundos
  Taxa de Produção: 666.67 itens/segundo
  Taxa de Consumo: 633.33 itens/segundo

======================================================================
```

## Conceitos Implementados

### Padrão Produtor-Consumidor
Implementação clássica do problema de sincronização onde múltiplos produtores geram dados e múltiplos consumidores os processam através de um buffer compartilhado.

### Sincronização com Semáforos
- **Semáforo de Espaços Vazios**: impede produtores de adicionar quando buffer está cheio
- **Semáforo de Itens Cheios**: impede consumidores de remover quando buffer está vazio

### Exclusão Mútua (Mutex)
Garante que apenas uma thread por vez possa modificar o buffer, evitando race conditions e garantindo integridade dos dados.

### Threading em Python
Uso de `threading.Thread`, `threading.Lock` e `threading.Semaphore` para implementar concorrência real.

## Validações Implementadas

O sistema valida automaticamente:
- Capacidade mínima do buffer (≥ 1000)
- Número mínimo de produtores (≥ 200)
- Número mínimo de consumidores (≥ produtores × 1.1)
- Número mínimo de timesteps (≥ 1.000.000)

## Análise de Desempenho

O sistema permite avaliar:
- **Eficiência**: taxa de consumo vs produção
- **Balanceamento**: equilíbrio entre produtores e consumidores
- **Capacidade do Buffer**: impacto no desempenho
- **Gargalos**: identificação de esperas excessivas

## Possíveis Experimentos

1. **Variação de Capacidade do Buffer**: testar impacto de diferentes tamanhos
2. **Razão Produtores/Consumidores**: encontrar configuração ótima
3. **Escalabilidade**: avaliar desempenho com mais threads
4. **Tempo de Processamento**: ajustar delays para simular diferentes cargas

## Limitações Conhecidas

- Simulação simplificada (não considera falhas de hardware)
- Tempo de processamento simulado com delays aleatórios
- Não implementa prioridades de peças
- Buffer implementado como lista (não otimizado para alta performance)

## Melhorias Futuras

- [ ] Implementar diferentes tipos de peças com prioridades
- [ ] Adicionar falhas aleatórias e recuperação
- [ ] Usar `queue.Queue` para melhor performance
- [ ] Implementar múltiplas etapas de processamento
- [ ] Dashboard em tempo real com visualização web
- [ ] Persistência de estado para retomada de simulações

## Autor

Projeto desenvolvido para a disciplina de Sistemas Distribuídos.

## Licença

Este projeto é disponibilizado para fins educacionais.
