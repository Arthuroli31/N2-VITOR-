# Análise dos Requisitos - Sistema de Controle para Linha de Produção Industrial

## Objetivo
Criar uma simulação de linha de produção industrial usando threads em Python, coordenando processos de entrada e saída de peças usando o padrão Produtor-Consumidor.

## Componentes Principais

### 1. Buffer (Fila de Processamento)
- Capacidade fixa (mínimo 1000 itens)
- Armazena peças aguardando processamento
- Implementar usando estrutura de dados (fila/lista)

### 2. Produtores
- Adicionam peças ao buffer
- Só operam se houver espaço disponível
- Esperam quando buffer está cheio
- Produtividade fixa por timestep
- Mínimo 200 threads de produtores

### 3. Consumidores
- Retiram peças do buffer
- Só operam se houver peças disponíveis
- Esperam quando buffer está vazio
- Produtividade fixa por timestep
- Número mínimo: n_produtores + 10%
- Podem operar em paralelo com produtores

### 4. Sincronização
- **Semáforo de Espaço Disponível**: controla posições livres no buffer
- **Semáforo de Itens Disponíveis**: controla número de peças prontas
- **Mutex (Lock)**: garante acesso sincronizado ao buffer (evita race conditions)

### 5. Controle de Execução
- Interromper após número determinado de operações OU tempo específico
- Mínimo 1.000.000 timesteps

## Parâmetros de Entrada
- Capacidade do buffer (min 1000)
- Número de produtores (min 200)
- Número de consumidores (min n_produtores + 10%)
- Quantidade de timesteps (min 1.000.000)
- Threads identificadas automaticamente de modo procedural

## Saída Esperada
- Número total de itens produzidos e consumidos
- Status do buffer ao longo da execução
- Itens restantes no buffer (se houver)
- Tempo médio de espera (opcional)
- Relatórios e gráficos analíticos

## Exemplo Toy Problem
- Capacidade do Buffer: 10
- Número de Produtores: 2
- Número de Consumidores: 3
- Número Total de Timesteps: 100

## Entregáveis
1. Código Python (repositório git)
2. Relatório mostrando execução e resultados
3. Apresentação
4. Tabelas e gráficos analíticos comparando diferentes configurações
