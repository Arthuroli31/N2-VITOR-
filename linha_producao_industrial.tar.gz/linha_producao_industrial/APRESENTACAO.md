# Apresentação do Projeto
## Sistema de Controle para Linha de Produção Industrial

### Miniprojeto Distribuído N2 - Sistemas Distribuídos

---

## Visão Geral

Este projeto implementa uma simulação completa de uma **linha de produção industrial automatizada** usando o padrão clássico **Produtor-Consumidor** com programação multithread em Python.

A solução demonstra conceitos fundamentais de **sistemas distribuídos** e **programação concorrente**, incluindo sincronização de threads, exclusão mútua e controle de recursos compartilhados.

---

## Problema Abordado

### Contexto
Em uma linha de produção industrial, peças precisam ser processadas em etapas sucessivas. Cada etapa:
- Recebe peças de etapas anteriores (produtores)
- Processa as peças
- Envia para próximas etapas (consumidores)
- Possui capacidade limitada de armazenamento (buffer)

### Desafios
- **Sincronização**: coordenar múltiplas threads acessando recursos compartilhados
- **Race Conditions**: evitar condições de corrida no acesso ao buffer
- **Deadlock**: garantir que o sistema não trave
- **Eficiência**: maximizar throughput sem desperdício de recursos

---

## Solução Implementada

### Arquitetura

```
┌─────────────┐      ┌──────────────┐      ┌──────────────┐
│  Produtor 1 │─────▶│              │─────▶│ Consumidor 1 │
├─────────────┤      │              │      ├──────────────┤
│  Produtor 2 │─────▶│    BUFFER    │─────▶│ Consumidor 2 │
├─────────────┤      │   (Fila)     │      ├──────────────┤
│     ...     │─────▶│              │─────▶│     ...      │
├─────────────┤      │              │      ├──────────────┤
│  Produtor N │─────▶│              │─────▶│ Consumidor M │
└─────────────┘      └──────────────┘      └──────────────┘
```

### Componentes Principais

#### 1. Buffer (Fila de Processamento)
- Capacidade fixa configurável
- Armazena peças aguardando processamento
- Implementado como lista Python com controle thread-safe

#### 2. Threads Produtoras
- Adicionam peças ao buffer
- Bloqueiam quando buffer está cheio
- Identificação única e automática

#### 3. Threads Consumidoras
- Retiram peças do buffer
- Bloqueiam quando buffer está vazio
- Operam em paralelo com produtores

#### 4. Mecanismos de Sincronização

##### Semáforos
- **Semáforo de Espaço Disponível**: controla posições livres
  - Inicializado com capacidade do buffer
  - Decrementado por produtores
  - Incrementado por consumidores

- **Semáforo de Itens Disponíveis**: controla peças prontas
  - Inicializado com 0
  - Incrementado por produtores
  - Decrementado por consumidores

##### Mutex (Lock)
- Garante exclusão mútua no acesso ao buffer
- Evita race conditions
- Protege operações críticas

---

## Implementação Técnica

### Tecnologias Utilizadas
- **Linguagem**: Python 3.7+
- **Bibliotecas**:
  - `threading`: threads, locks e semáforos
  - `matplotlib`: visualizações
  - `pandas`: análise de dados
  - `numpy`: operações numéricas

### Estrutura de Arquivos

```
linha_producao_industrial/
├── production_line.py          # Implementação principal
├── analyze_results.py          # Análise e visualização
├── run_experiments.py          # Suite de experimentos
├── exemplo_completo.py         # Exemplos de uso
├── README.md                   # Documentação completa
├── requirements.txt            # Dependências
└── requisitos_projeto.md       # Análise dos requisitos
```

### Características do Código

#### Thread-Safe
- Uso correto de locks e semáforos
- Proteção de seções críticas
- Prevenção de race conditions

#### Configurável
- Parâmetros ajustáveis
- Validação de configurações
- Modo debug para testes

#### Instrumentado
- Coleta de estatísticas em tempo real
- Snapshots do buffer
- Métricas de desempenho

---

## Resultados e Análises

### Métricas Coletadas

#### Produção e Consumo
- Total de itens produzidos
- Total de itens consumidos
- Itens restantes no buffer
- Eficiência de consumo

#### Desempenho
- Tempo de execução
- Taxa de produção (itens/segundo)
- Taxa de consumo (itens/segundo)
- Throughput do sistema

#### Sincronização
- Número de esperas de produtores
- Número de esperas de consumidores
- Evolução do buffer ao longo do tempo

### Visualizações Geradas

#### 1. Evolução do Buffer
Gráfico de linha mostrando ocupação do buffer ao longo do tempo, permitindo identificar:
- Padrões de enchimento/esvaziamento
- Momentos de saturação
- Eficiência da configuração

#### 2. Produção vs Consumo
Gráfico de barras comparando:
- Total produzido
- Total consumido
- Itens restantes

#### 3. Tempos de Espera
Análise de bloqueios:
- Esperas de produtores (buffer cheio)
- Esperas de consumidores (buffer vazio)

#### 4. Comparação de Configurações
Análise comparativa de múltiplas execuções:
- Impacto da capacidade do buffer
- Efeito da razão produtores/consumidores
- Identificação de configuração ótima

---

## Experimentos Realizados

### Configuração 1: Toy Problem
- **Buffer**: 10 itens
- **Produtores**: 2
- **Consumidores**: 3
- **Timesteps**: 100
- **Objetivo**: Validação rápida do sistema

### Configuração 2: Buffer Pequeno
- **Buffer**: 1.000 itens
- **Produtores**: 200
- **Consumidores**: 220
- **Timesteps**: 10.000
- **Objetivo**: Avaliar comportamento com buffer limitado

### Configuração 3: Buffer Médio
- **Buffer**: 5.000 itens
- **Produtores**: 200
- **Consumidores**: 220
- **Timesteps**: 10.000
- **Objetivo**: Configuração balanceada

### Configuração 4: Buffer Grande
- **Buffer**: 10.000 itens
- **Produtores**: 200
- **Consumidores**: 220
- **Timesteps**: 10.000
- **Objetivo**: Avaliar impacto de buffer grande

### Configuração 5: Mais Consumidores
- **Buffer**: 5.000 itens
- **Produtores**: 200
- **Consumidores**: 300
- **Timesteps**: 10.000
- **Objetivo**: Testar desbalanceamento

---

## Conclusões

### Aprendizados

#### 1. Sincronização é Fundamental
O uso correto de semáforos e mutex é essencial para:
- Evitar race conditions
- Prevenir deadlocks
- Garantir integridade dos dados

#### 2. Balanceamento é Crítico
A razão entre produtores e consumidores afeta diretamente:
- Eficiência do sistema
- Ocupação do buffer
- Throughput geral

#### 3. Capacidade do Buffer
Buffer maior:
- ✓ Reduz esperas
- ✓ Aumenta throughput
- ✗ Consome mais memória

Buffer menor:
- ✓ Economia de memória
- ✗ Mais bloqueios
- ✗ Menor throughput

### Aplicações Práticas

Este padrão é usado em:
- **Sistemas de mensageria**: Kafka, RabbitMQ
- **Processamento de streams**: Apache Flink, Spark Streaming
- **Pipelines de dados**: ETL, data processing
- **Sistemas operacionais**: buffers de I/O
- **Aplicações web**: thread pools, request queues

---

## Como Executar

### Instalação
```bash
# Clone ou extraia o projeto
cd linha_producao_industrial

# Instale dependências
pip install -r requirements.txt
```

### Execução Rápida (Toy Problem)
```bash
python3 production_line.py
```

### Execução Completa
```bash
python3 exemplo_completo.py
```

### Suite de Experimentos
```bash
python3 run_experiments.py
```

### Análise de Resultados
```bash
python3 analyze_results.py
```

---

## Requisitos Atendidos

✅ Buffer com capacidade limitada  
✅ Múltiplos produtores e consumidores (threads)  
✅ Sincronização com semáforos  
✅ Exclusão mútua com mutex  
✅ Identificação automática de threads  
✅ Controle de execução por timesteps  
✅ Relatórios detalhados  
✅ Visualizações gráficas  
✅ Análise comparativa  
✅ Código em repositório git  
✅ Documentação completa  

---

## Referências

- **Tanenbaum, A. S.** - Modern Operating Systems
- **Silberschatz, A.** - Operating System Concepts
- **Python Threading Documentation**: https://docs.python.org/3/library/threading.html
- **Producer-Consumer Problem**: Classic synchronization problem

---

## Autor

Projeto desenvolvido para a disciplina de **Sistemas Distribuídos**.

**Data**: Dezembro 2025
